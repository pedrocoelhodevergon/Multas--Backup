"""DebugRunner — infraestrutura para rodar tasks Ergon FORA do framework.

> Uso (modo DEBUGGER, espelhando o antigo `tasks/run.py`): instancia um
> `ergon.task.TaskConfig` em uma task executável, resolvendo os `services`,
> `connectors` (built-in ou dry-run, conforme credenciais) e `policies` das
> configurações — e chama o fluxo. Permite testar TODO o processo e CADA task
> individualmente, sem o manager do framework.

Requer a superfície real (ou o shim de teste) do `ergon`. É *infra* compartilhada,
então NÃO carrega lógica de domínio de nenhum dos pacotes.
"""

from __future__ import annotations

from typing import Any


def _instantiate_cfg(cfg: Any) -> Any:
    """Instancia um ServiceConfig/ConnectorConfig em um objeto real."""
    if cfg is None:
        return None
    cls = getattr(cfg, "service", None) or getattr(cfg, "connector", None)
    kwargs = getattr(cfg, "kwargs", None) or {}
    if cls is None:
        return cfg  # já é uma instância pronta
    try:
        return cls(**kwargs)
    except TypeError:
        return cls


def instantiate_task(task_config: Any) -> Any:
    """Monta uma instância de task com os services/connectors/policies injetados.

    Os atributos seguem a convenção do framework:
      services   `{key}`  -> `{key}_service`
      connectors `{key}`  -> `{key}_connector`
      policies   `{name}` -> `{name}_policy`
    E também as coleções `task.services`, `task.connectors`.
    """
    task = task_config.task()

    # Coleções no formato que o framework/mixins esperam.
    task.services = dict(task_config.services or {})
    task.connectors = dict(task_config.connectors or {})

    for key, cfg in (task_config.services or {}).items():
        setattr(task, f"{key}_service", _instantiate_cfg(cfg))

    for key, cfg in (task_config.connectors or {}).items():
        setattr(task, f"{key}_connector", _instantiate_cfg(cfg))

    for policy in (task_config.policies or []):
        setattr(task, f"{policy.name}_policy", policy)

    return task


def run_task(task_config: Any, **kwargs: Any) -> Any:
    """Instancia a task e a executa via `execute(**kwargs)` (ou com o os kwargs)."""
    task = instantiate_task(task_config)
    if kwargs:
        return task.execute(**kwargs)
    return task.execute()
