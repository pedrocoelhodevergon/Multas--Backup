"""TaskRunner — infraestrutura para instanciar e rodar tasks Ergon FORA do framework.

> Usado pelos runners locais (`tasks/run.py` de cada domínio). Constrói uma
> `ergon.task.TaskConfig` em uma task executável resolvendo os `services`,
> `connectors` (built-in ou, ausentes credenciais, o dry-run definido em
> `settings`) e `policies` das configurações — e chama o fluxo real.

Requer a superfície real (ou o shim de teste) do `ergon`. É *infra* compartilhada,
ENTÃO NÃO carrega lógica de domínio de nenhum dos pacotes.
"""

from __future__ import annotations

from typing import Any


def _instantiate_cfg(cfg: Any) -> Any:
    """Instancia um ServiceConfig/ConnectorConfig em um objeto real."""
    if cfg is None:
        return None
    cls = getattr(cfg, "service", None) or getattr(cfg, "connector", None)
    kwargs = getattr(cfg, "kwargs", None) or {}
    if cls is None:
        return cfg  # já é uma instância pronta
    try:
        return cls(**kwargs)
    except TypeError:
        return cls


def instantiate_task(task_config: Any) -> Any:
    """Monta uma instância de task com os services/connectors/policies injetados.

    Os atributos seguem a convenção do framework:
      services   `{key}`  -> `{key}_service`
      connectors `{key}`  -> `{key}_connector`
      policies   `{name}` -> `{name}_policy`
    E também as coleções `task.services`, `task.connectors`.

    Os services/connectors resolvidos são os REAIS definidos em `settings` (com
    o fallback de dry-run já embutido em cada `build_*_connector()`). Não há modo
    mock aqui: quando força um valor, isso é feito pelo próprio `settings`.
    """
    services = dict(task_config.services or {})
    connectors = dict(task_config.connectors or {})
    policies = list(task_config.policies or [])

    # O TaskMeta do framework real exige as três coleções na instanciação.
    # O fallback mantém compatibilidade com a superfície simplificada usada
    # nos testes locais.
    try:
        task = task_config.task(connectors, services, policies)
    except TypeError as exc:
        if "required positional argument" not in str(exc) and "positional arguments" not in str(exc):
            raise
        task = task_config.task()

    # O framework ConsumerMixin usa task.connectors diretamente durante
    # consume_transactions(). Essas coleções precisam conter instâncias reais,
    # não ConnectorConfig/ServiceConfig.
    resolved_services = {
        key: _instantiate_cfg(cfg) for key, cfg in services.items()
    }
    resolved_connectors = {
        key: _instantiate_cfg(cfg) for key, cfg in connectors.items()
    }
    task.services = resolved_services
    task.connectors = resolved_connectors

    for key, instance in resolved_services.items():
        setattr(task, f"{key}_service", instance)

    for key, instance in resolved_connectors.items():
        setattr(task, f"{key}_connector", instance)

    for policy in (task_config.policies or []):
        setattr(task, f"{policy.name}_policy", policy)

    return task


def run_task(task_config: Any, **kwargs: Any) -> Any:
    """Instancia a task e a executa via `execute(**kwargs)` (ou sem kwargs)."""
    task = instantiate_task(task_config)
    if kwargs:
        return task.execute(**kwargs)
    return task.execute()
