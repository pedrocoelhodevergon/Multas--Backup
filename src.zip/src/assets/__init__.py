"""Infraestrutura compartilhada entre domínios (assets — nunca lógica de domínio)."""

from __future__ import annotations

from assets.task_runner import instantiate_task  # noqa: F401

__all__ = ["instantiate_task"]
