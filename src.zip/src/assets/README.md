# assets

Repositório **compartilhado** de artefatos (infra) usados pelos runners locais
dos domínios de Ativos e Multas. Aqui ficam apenas **arquivos** (não código):
planilhas de entrada, imagens de assinatura, formulários-base e afins.

> Os domínios **nunca importam código um do outro** — mas compartilham esta
> pasta de infra. O caminho é resolvido via `resolver_assets_dir()` em cada
> pacote; pode ser sobrescrito pela env `ASSETS_DIR`.

## Subpastas

| Pasta | Uso | Domínio |
|---|---|---|
| `planilhas_sap/` | planilhas Excel SAP (entrada da auditoria) | Ativos (`auditoria_inativacoes`) |
| `assinaturas/` | imagem de assinatura digital do condutor | Multas (`extracao_multas_lw`) |
| `formularios/` | templates base (formulários de indicação) | Multas |

## Como os runners usam

- **Ativos** — `tasks/run.py` lê as planilhas SAP de `assets/planilhas_sap/`.
- **Multas** — `tasks/run.py` procura a assinatura em `assets/assinaturas/`
  (env `CAMINHO_ASSINATURA` tem prioridade; se ausente, gera uma assinatura mock).
