"""Compatibilidade para o entrypoint histórico do domínio de Ativos.

O CLI oficial fica em `atualizacao_ativos.cli`. Este módulo permanece para
compatibilidade com `python -m atualizacao_ativos.main` e com instalações que
já apontem para `atualizacao_ativos.main:main`.
"""

from __future__ import annotations

from atualizacao_ativos.cli import main


if __name__ == "__main__":
    main()
