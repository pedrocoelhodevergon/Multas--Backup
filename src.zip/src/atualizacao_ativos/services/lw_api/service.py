"""LwApiService — protocolo/domínio da API LW Tecnologia (SÓ ATIVOS).

Fala com UMA sistema externo (a LW), expondo um método por operação de negócio.
O transporte HTTP/auth vive aqui mesmo (sessão, tokens JWT V1/V2, roteamento do
Bearer por URL) — as funções auxiliares vêm do módulo `client` do projeto.

> Escopo: apenas o fluxo de ATIVOS / VEÍCULOS (auditoria SAP→LW, inativar,
> ativar, mobilizar, grupos/centro de custo e CRUD de frota).
> Toda a superfície de MULTAS (órgãos, busca por placa/período/AIT, imagens,
> indicação de condutor, status de pagamento) foi REMOVIDA — pertence a outro
> projeto e não é usada aqui.
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any, Optional

import requests

from .client import bool_query_param, ensure_list, join_url, normalize_bearer_token
from .schema import (
    AlterarEmailGrupo,
    AtualizarVeiculo,
    CadastrarGrupo,
    CadastrarVeiculo,
    DesvincularCondutorVeiculo,
    DesvincularVeiculoGrupo,
    LwApiConfig,
    VincularCondutorVeiculo,
    VincularVeiculoGrupo,
    VincularVeiculoGrupoCentroCusto,
)

logger = logging.getLogger(__name__)

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
)


class LwApiService:
    """Cliente de protocolo da API LW Tecnologia — gestão de ativos/veículos."""

    def __init__(self, config: LwApiConfig):
        self.config = config
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": USER_AGENT,
            }
        )

        self.v1_base_url = os.getenv(
            "LW_API_V1_BASE_URL", "https://api.lwtecnologia.com.br/api"
        )
        self.v1_token = normalize_bearer_token(os.getenv("LW_API_V1_TOKEN", ""))

        self.v2_base_url = os.getenv(
            "LW_API_V2_BASE_URL", "https://api.sistemamultas.com.br/api/v2"
        )
        self.v2_token = normalize_bearer_token(os.getenv("LW_API_V2_TOKEN", ""))

        if not self.v1_token and not self.v2_token:
            logger.warning(
                "⚠️ Nenhum token JWT foi encontrado no .env. As requisições falharão com 401/403."
            )
        else:
            logger.info("🔑 Tokens JWT (V1 e V2) carregados com sucesso do ambiente.")

    def get_token(self) -> str:
        return self.v1_token

    # ------------------------------------------------------------------
    # Transporte
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict[str, Any]] = None,
        json_body: Any = None,
        raw: bool = False,
        timeout: Optional[int] = None,
    ) -> Any:
        url = (
            path
            if path.startswith("http://") or path.startswith("https://")
            else join_url(self.config.base_url, path)
        )
        request_timeout = timeout if timeout is not None else self.config.timeout_sec
        request_headers = dict(self.session.headers)

        # Roteia o Bearer conforme a superfície (V2 = sistemamultas ou /v2/).
        if "sistemamultas.com.br" in url or "/v2/" in url:
            if self.v2_token:
                request_headers["Authorization"] = f"Bearer {self.v2_token}"
            else:
                logger.warning(
                    "⚠️ Tentando acessar endpoint V2, mas LW_API_V2_TOKEN está vazio no .env!"
                )
        else:
            if self.v1_token:
                request_headers["Authorization"] = f"Bearer {self.v1_token}"
            else:
                logger.warning(
                    "⚠️ Tentando acessar endpoint V1, mas LW_API_V1_TOKEN está vazio no .env!"
                )

        response = self.session.request(
            method,
            url,
            headers=request_headers,
            params=params,
            json=json_body,
            timeout=request_timeout,
        )
        response.raise_for_status()
        if raw:
            return response.content
        if not response.content:
            return None
        return response.json()

    @staticmethod
    def _to_payload(data: Any) -> dict[str, Any]:
        if hasattr(data, "model_dump"):
            return data.model_dump(exclude_none=True)
        return dict(data)

    # ==================================================================
    # FLUXO DE GESTÃO DE ATIVOS E INATIVAÇÕES (MC01 e MC02)
    # ==================================================================

    def consultar_veiculo_unico_v2(self, placa: str) -> Optional[dict[str, Any]]:
        """Consulta direta de uma única placa na V2 com o Payload oficial de ATIVOS."""
        url_v2 = f"{self.v2_base_url}/multas/veiculos/listar"

        payload_ativos = {
            "placas": [placa],
            "statusFrota": 0,
            "dataVenda": {"dataInicio": None, "dataFim": None},
            "dataCompra": {"dataInicio": None, "dataFim": None},
            "statusVeiculoPagamento": None,
            "naoUsarTotal": True,
        }

        params = {"page": 1, "limit": 100}
        data = self._request("POST", url_v2, params=params, json_body=payload_ativos, timeout=60)

        if data and isinstance(data, dict) and "dados" in data:
            return data["dados"][0] if data["dados"] else None
        elif data and isinstance(data, list):
            return data[0] if data else None
        return None

    def consultar_veiculos_v2_por_placas(self, placas: list[str]) -> list[dict[str, Any]]:
        """Consulta em lote na V2 com o Payload oficial de ATIVOS."""
        if not placas:
            return []

        url_v2 = f"{self.v2_base_url}/multas/veiculos/listar"
        veiculos_totais = []
        TAMANHO_LOTE = 500

        for i in range(0, len(placas), TAMANHO_LOTE):
            lote_placas = placas[i : i + TAMANHO_LOTE]

            payload_ativos = {
                "placas": lote_placas,
                "statusFrota": 0,
                "dataVenda": {"dataInicio": None, "dataFim": None},
                "dataCompra": {"dataInicio": None, "dataFim": None},
                "statusVeiculoPagamento": None,
                "naoUsarTotal": True,
            }

            pagina_atual = 1
            limite_por_pagina = 100

            while True:
                params = {"page": pagina_atual, "limit": limite_por_pagina}
                data = self._request(
                    "POST", url_v2, params=params, json_body=payload_ativos, timeout=60
                )

                if data and isinstance(data, dict) and "dados" in data:
                    lote_resultados = data.get("dados", [])
                    veiculos_totais.extend(lote_resultados)
                    if not lote_resultados or len(lote_resultados) < limite_por_pagina:
                        break
                    pagina_atual += 1
                else:
                    veiculos_totais.extend(ensure_list(data))
                    break

        return veiculos_totais

    def listar_todos_ativos(self) -> list[dict[str, Any]]:
        """Busca TODOS os veículos ativos na plataforma da LW."""
        url_v2 = f"{self.v2_base_url}/multas/veiculos/listar"

        payload_ativos = {
            "placas": [],
            "statusFrota": 0,
            "dataVenda": {"dataInicio": None, "dataFim": None},
            "dataCompra": {"dataInicio": None, "dataFim": None},
            "statusVeiculoPagamento": None,
            "naoUsarTotal": True,
        }

        veiculos_totais = []
        pagina_atual = 1
        limite_por_pagina = 100

        logger.info("📡 Iniciando download massivo de veículos ATIVOS na LW...")

        while True:
            params = {"page": pagina_atual, "limit": limite_por_pagina}
            data = self._request("POST", url_v2, params=params, json_body=payload_ativos, timeout=60)

            if data and isinstance(data, dict) and "dados" in data:
                lote = data.get("dados", [])
                veiculos_totais.extend(lote)

                if pagina_atual % 10 == 0:
                    logger.info(f"   ⏳ Baixadas {len(veiculos_totais)} placas da API...")

                if not lote or len(lote) < limite_por_pagina:
                    break
                pagina_atual += 1
            else:
                break

        logger.info(f"✅ Download concluído! Total de veículos ativos na LW: {len(veiculos_totais)}")
        return veiculos_totais

    def listar_todos_veiculos(self) -> list[dict[str, Any]]:
        """Borra a frota via V1 e cruza com a V2 (usa consulta em lote)."""
        url_v1 = f"{self.v1_base_url}/veiculos/"
        data_v1 = self._request("GET", url_v1, timeout=60)
        lista_v1 = ensure_list(data_v1)
        placas_capturadas = list({v.get("placa") for v in lista_v1 if v.get("placa")})

        if not placas_capturadas:
            return []

        return self.consultar_veiculos_v2_por_placas(placas_capturadas)

    # ------------------------------------------------------------------
    # Atualização / inativação / ativação oficiais (LW V2)
    # ------------------------------------------------------------------

    def atualizar_veiculo_v2(
        self,
        *,
        id_veiculo: int | str,
        id_cliente: int | str,
        placa: str,
        renavam: str,
        chassi: str,
        status: int,
        centro_custo: Optional[str] = None,
    ) -> tuple[bool, str]:
        """
        ENDPOINT DE ATUALIZAÇÃO / PERSISTÊNCIA:
        POST https://api.sistemamultas.com.br/api/v2/multas/veiculos
        """
        url_post_atualizacao = "https://api.sistemamultas.com.br/api/v2/multas/veiculos"

        payload = {
            "id": int(id_veiculo) if str(id_veiculo).isdigit() else id_veiculo,
            "idCliente": int(id_cliente) if str(id_cliente).isdigit() else id_cliente,
            "placa": placa,
            "renavam": str(renavam),
            "chassi": str(chassi),
            "status": int(status),
        }

        if centro_custo and str(centro_custo).strip() not in [
            "SEM_CC_NO_SAP",
            "NÃO INFORMADO",
            "N/A",
        ]:
            payload["grupos"] = [
                {"centroCusto": str(centro_custo).strip(), "cnpj": str(centro_custo).strip()}
            ]

        try:
            logger.info(f"🚀 Disparando POST de atualização LW para a placa {placa} | Payload: {payload}")
            res_data = self._request("POST", url_post_atualizacao, json_body=payload, timeout=20)
            logger.info(f"✅ Sucesso na atualização LW ({placa}): {res_data}")
            return True, f"HTTP 200 - {res_data}"
        except Exception as e:
            msg_erro = str(e)
            logger.error(f"❌ Falha no POST de atualização para a placa {placa}: {msg_erro}")
            return False, msg_erro

    def inativar_veiculos_v2(self, ids_veiculos: list[int], id_cliente: int = 167) -> tuple[bool, str]:
        """Inativa um ou mais veículos na plataforma LW (V2)."""
        if not isinstance(ids_veiculos, list):
            ids_veiculos = [ids_veiculos]

        url_inativacao = f"{self.v2_base_url}/multas/veiculos/inativar"
        payload = {"idsVeiculos": [int(v) for v in ids_veiculos], "idCliente": int(id_cliente)}

        try:
            logger.info(f"🚀 Disparando inativação LW para os IDs {ids_veiculos} | Cliente: {id_cliente}")
            res_data = self._request("POST", url_inativacao, json_body=payload, timeout=20)
            logger.info(f"✅ Sucesso na inativação LW: {res_data}")
            return True, f"Sucesso - {res_data}"
        except Exception as e:
            msg_erro = str(e)
            logger.error(f"❌ Falha ao inativar veículos na LW (IDs: {ids_veiculos}): {msg_erro}")
            return False, msg_erro

    def ativar_veiculos_v2(self, ids_veiculos: list[int], id_cliente: int = 167) -> tuple[bool, str]:
        """Ativa um ou mais veículos na plataforma LW (V2)."""
        if not isinstance(ids_veiculos, list):
            ids_veiculos = [ids_veiculos]

        url_ativacao = f"{self.v2_base_url}/multas/veiculos/ativar"
        payload = {"idsVeiculos": [int(v) for v in ids_veiculos], "idCliente": int(id_cliente)}

        try:
            logger.info(f"🚀 Disparando ativação LW para os IDs {ids_veiculos} | Cliente: {id_cliente}")
            res_data = self._request("POST", url_ativacao, json_body=payload, timeout=20)
            logger.info(f"✅ Sucesso na ativação LW: {res_data}")
            return True, f"Sucesso - {res_data}"
        except Exception as e:
            msg_erro = str(e)
            logger.error(f"❌ Falha ao ativar veículos na LW (IDs: {ids_veiculos}): {msg_erro}")
            return False, msg_erro

    # ------------------------------------------------------------------
    # Grupos / centro de custo
    # ------------------------------------------------------------------

    def cadastrar_grupo_centro_custo(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Cadastra grupo/centro de custo pela API V2 observada no portal."""
        url = "https://api.sistemamultas.com.br/v2/grupos/cadastrar"
        # id/status/datas são campos de resposta; não devem ser inventados no POST.
        body = {
            "centroCusto": payload["centroCusto"],
            "nomeGrupo": payload["nomeGrupo"],
            "cnpj": payload["cnpj"],
            "telefone": payload.get("telefone", ""),
            "email": payload.get("email", ""),
            "emailCopia": payload.get("emailCopia", ""),
        }
        result = self._request("POST", url, json_body=body, timeout=30)
        if not isinstance(result, dict):
            raise ValueError(f"Resposta inesperada ao cadastrar centro de custo: {result!r}")
        return result

    def listar_grupos(self, id_cliente: int = 167) -> list[dict]:
        """Busca todos os grupos e centros de custo atrelados ao cliente na LW."""
        url = "https://api.sistemamultas.com.br/v2/grupos/?paginate=false"
        payload = {"idsClientes": [id_cliente], "default": True}

        try:
            logger.info(f"🔍 Mapeando grupos/centros de custo na LW para o cliente {id_cliente}...")
            response = self._request("POST", url, json_body=payload, timeout=30)
            grupos = response if isinstance(response, list) else response.get("dados", [])
            logger.info(f"✅ {len(grupos)} grupos mapeados com sucesso na memória.")
            return grupos
        except Exception as e:
            logger.error(f"❌ Erro ao listar grupos da LW: {str(e)}")
            return []

    def mobilizar_veiculo_grupo(
        self,
        id_veiculo: int,
        id_grupo: int,
        id_cliente: int = 167,
        id_grupo_historico: int = 0,
    ) -> tuple[bool, str]:
        """Mobiliza (altera o vínculo) de um veículo para um novo grupo (Centro de Custo)."""
        url_mobilizar = "https://api.sistemamultas.com.br/v2/grupos/editar/mobilizar"
        data_inicio_iso = time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())

        payload = {
            "idGrupoHistorico": int(id_grupo_historico),
            "idGrupo": int(id_grupo),
            "dataInicio": data_inicio_iso,
            "statusVeic": False,
            "idVeiculo": int(id_veiculo),
            "idCliente": int(id_cliente),
        }

        try:
            logger.info(f"🚀 Mobilizando veículo ID {id_veiculo} | Grupo Destino ID {id_grupo}")
            res_data = self._request("POST", url_mobilizar, json_body=payload, timeout=20)
            logger.info(f"✅ Sucesso ao mobilizar veículo ID {id_veiculo}: {res_data}")
            return True, f"Sucesso - {res_data}"
        except Exception as e:
            msg_erro = str(e)
            # A LW retorna 200/201 com corpo texto puro ("Veiculo foi mobilizado").
            if "Expecting value" in msg_erro or "JSONDecodeError" in msg_erro:
                msg_sucesso = "Veículo foi mobilizado com sucesso"
                logger.info(f"✅ Sucesso ao mobilizar veículo ID {id_veiculo}: {msg_sucesso}")
                return True, f"Sucesso - {msg_sucesso}"
            logger.error(f"❌ Falha ao mobilizar veículo (ID: {id_veiculo}): {msg_erro}")
            return False, msg_erro

    # ------------------------------------------------------------------
    # CRUD de frota / grupos (V1 e V2)
    # ------------------------------------------------------------------

    def cadastrar_grupo(self, dados: dict[str, Any] | CadastrarGrupo) -> Any:
        return self._request("POST", "veiculos/cadastrarGrupo", json_body=self._to_payload(dados))

    def vincular_veiculo_grupo(self, dados: dict[str, Any] | VincularVeiculoGrupo) -> Any:
        return self._request("POST", "veiculos/vincularVeiculoGrupo", json_body=self._to_payload(dados))

    def vincular_veiculo_grupo_centro_custo(
        self, dados: dict[str, Any] | VincularVeiculoGrupoCentroCusto
    ) -> Any:
        return self._request("POST", "veiculos/vincularVeiculoGrupo/centroCusto", json_body=self._to_payload(dados))

    def consultar_veiculos_grupo(
        self, *, centro_custo: str | None = None, cod_cliente: str | None = None
    ) -> dict[str, Any] | None:
        params = {
            key: value
            for key, value in {"centro_custo": centro_custo, "codCliente": cod_cliente}.items()
            if value is not None
        }
        data = self._request("GET", "veiculos/consultarVeiculosGrupo", params=params)
        return data if isinstance(data, dict) else None

    def desvincular_veiculo_grupo(self, dados: dict[str, Any] | DesvincularVeiculoGrupo) -> Any:
        return self._request("POST", "veiculos/desvincularVeiculoGrupo", json_body=self._to_payload(dados))

    def alterar_email_grupo(self, dados: dict[str, Any] | AlterarEmailGrupo) -> Any:
        return self._request("POST", "veiculos/alterarEmail", json_body=self._to_payload(dados))

    def alterar_email_copia_grupo(self, dados: dict[str, Any] | AlterarEmailGrupo) -> Any:
        return self._request("POST", "veiculos/alterarEmailCopia", json_body=self._to_payload(dados))

    def cadastrar_veiculo(self, dados: dict[str, Any] | CadastrarVeiculo) -> dict[str, Any] | None:
        data = self._request("POST", "veiculos/cadastrarVeiculo", json_body=self._to_payload(dados))
        return data if isinstance(data, dict) else None

    def listar_veiculos(self) -> list[dict[str, Any]]:
        data = self._request("GET", "veiculos")
        return ensure_list(data)

    def listar_veiculos_paginados(self, page: int = 0, size: int = 20) -> dict[str, Any] | None:
        data = self._request("GET", "v1/veiculos/todosVeiculos", params={"page": page, "size": size})
        return data if isinstance(data, dict) else None

    def atualizar_veiculo(self, id_veiculo: str | int, dados: dict[str, Any] | AtualizarVeiculo) -> Any:
        return self._request("PUT", f"veiculos/{id_veiculo}", json_body=self._to_payload(dados))

    def atualizar_placa_mercosul(self, id_veiculo: str | int) -> Any:
        return self._request("PATCH", f"veiculos/{id_veiculo}/placaMercosul")

    def inativar_veiculo(self, placa: str) -> Any:
        return self._request("DELETE", f"veiculos/inativarVeiculo/{placa}")

    # ------------------------------------------------------------------
    # Vínculo condutor <-> veículo (gestão de frota)
    # ------------------------------------------------------------------

    def consultar_vinculos_veiculo_condutor(self, placa: str) -> list[dict[str, Any]]:
        data = self._request("GET", f"veiculos/consultarVinculosVeiculoCondutor/{placa}")
        return ensure_list(data)

    def vincular_condutor_veiculo(self, dados: dict[str, Any] | VincularCondutorVeiculo) -> Any:
        return self._request("POST", "veiculos/vincularCondutorVeiculo", json_body=self._to_payload(dados))

    def desvincular_condutor_veiculo(self, dados: dict[str, Any] | DesvincularCondutorVeiculo) -> Any:
        return self._request("POST", "veiculos/desvincularCondutorVeiculo", json_body=self._to_payload(dados))
