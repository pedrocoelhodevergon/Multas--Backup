"""Modelos da API LW Tecnologia — SÓ ATIVOS / VEÍCULOS.

> Modelos de MULTAS (Multa, Condutor, Orgao, ImagemMulta, StatusIndicacao*, etc.)
> foram REMOVIDOS — pertencem a outro projeto.
"""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


class LwApiConfig(BaseModel):
    """Credenciais e endpoint base da API LW Tecnologia."""

    base_url: str = "https://api.lwtecnologia.com.br/api"
    login: str
    senha: str
    timeout_sec: float = 30.0


# ---------------------------------------------------------------------------
# Mobilização / desmobilização de veículos
# ---------------------------------------------------------------------------


class GrupoVeiculo(BaseModel):
    nomeResponsavel: Optional[str] = None
    email: Optional[str] = None
    codCliente: Optional[str] = None
    centro_custo: Optional[str] = None

    model_config = {"extra": "allow"}


class Veiculo(BaseModel):
    id_veiculo: Optional[int] = None
    placa: Optional[str] = None
    renavam: Optional[str] = None
    chassi: Optional[str] = None
    tipo: Optional[str] = None
    marca_modelo: Optional[str] = None
    ano_fabricacao: Optional[str] = None
    ano_modelo: Optional[str] = None
    cor: Optional[str] = None
    combustivel_potencia: Optional[str] = None
    cidade_uf: Optional[str] = None
    status: Optional[str] = None
    usamarcadagua: Optional[bool] = None

    model_config = {"extra": "allow"}


class VinculoVeiculoCondutor(BaseModel):
    placa: Optional[str] = None
    cod_cliente: Optional[str] = None
    nome_grupo: Optional[str] = None
    condutor_nome: Optional[str] = None
    condutor_email: Optional[str] = None
    data_hora_inicio: Optional[str] = None
    data_hora_fim: Optional[str] = None

    model_config = {"extra": "allow"}


class VeiculosPaginados(BaseModel):
    veiculos: list[Veiculo | dict[str, Any]] = Field(default_factory=list)
    totalPages: Optional[int] = None
    totalElements: Optional[int] = None

    model_config = {"extra": "allow"}


class CadastrarGrupo(BaseModel):
    nome: str
    cpf_cnpj: str


class VincularVeiculoGrupo(BaseModel):
    cpf_cnpj: str
    placa: str
    data_hora_inicio: str


class VincularVeiculoGrupoCentroCusto(VincularVeiculoGrupo):
    centro_custo: str
    numero_proposta: str


class AlterarEmailGrupo(BaseModel):
    cnpj: str
    email: str


class CadastrarVeiculo(BaseModel):
    placa: str
    chassi: str
    renavam: str
    uf_veic: str


class CadastrarVeiculoResponse(BaseModel):
    id: Optional[int] = None

    model_config = {"extra": "allow"}


class VincularCondutorVeiculo(BaseModel):
    condutor_cpf: str
    condutor_email: str
    condutor_nome: str
    cpf_cnpj: str
    data_hora_inicio: str
    placa: str


class AtualizarVeiculo(BaseModel):
    renavam: str
    chassi: str
    tipo: Optional[str] = None
    marcaModelo: Optional[str] = None
    ano_fabricacao: Optional[str] = None
    ano_modelo: Optional[str] = None
    cor: Optional[str] = None
    combustivel: Optional[str] = None
    potencia: Optional[str] = None
    cidade_uf: Optional[str] = None
    uf_veic: Optional[str] = None

    model_config = {"extra": "allow"}


class DesvincularCondutorVeiculo(BaseModel):
    data_hora_fim: str
    placa: str


class DesvincularVeiculoGrupo(BaseModel):
    data_hora_fim: str
    cpf_cnpj: str
    placa: str
