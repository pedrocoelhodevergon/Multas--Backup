"""client.py — funções auxiliares do cliente da API LW.

> Módulo real do projeto: contém apenas utilidades de URL/token/listas.
> O transporte HTTP/auth vive dentro do `LwApiService` (ver service.py).
"""

from __future__ import annotations

from typing import Any


def normalize_bearer_token(token: str | None) -> str:
    """Remove o prefixo 'Bearer ' se a API já o incluir na resposta."""
    if not token:
        raise ValueError("Token JWT ausente na resposta da LW.")
    cleaned = token.strip()
    if cleaned.lower().startswith("bearer "):
        cleaned = cleaned[7:].strip()
    if not cleaned:
        raise ValueError("Token JWT vazio após normalização.")
    return cleaned


def bool_query_param(value: bool) -> str:
    """A API LW exige boolean como string minúscula na query string."""
    return "true" if value else "false"


def ensure_list(payload: Any) -> list:
    """Garante lista; se a API retornar objeto único, envelopa em lista."""
    if payload is None:
        return []
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        return [payload]
    return []


def join_url(base_url: str, *parts: str) -> str:
    """Concatena base_url e path segments sem barras duplicadas."""
    base = base_url.rstrip("/")
    suffix = "/".join(p.strip("/") for p in parts if p)
    return f"{base}/{suffix}" if suffix else base
