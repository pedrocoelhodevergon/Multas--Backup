"""Camada de integração com a API LW Tecnologia (SÓ ATIVOS)."""

from .schema import LwApiConfig
from .service import LwApiService

__all__ = ["LwApiConfig", "LwApiService"]
