"""Normalização do payload retornado pela Ergon Platform."""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any
import logging

logger = logging.getLogger(__name__)


def _dump(value: Any) -> Any:
    return value.model_dump() if hasattr(value, "model_dump") else value


def _field_name_value(field: Any) -> tuple[str | None, Any]:
    field = _dump(field)
    if isinstance(field, Mapping):
        name = (
            field.get("field_name")
            or field.get("fieldName")
            or field.get("column_name")
            or field.get("columnName")
            or field.get("name")
            or field.get("label")
            or field.get("field_id")
            or field.get("id")
        )
        value = (
            field.get("value")
            if "value" in field
            else field.get("field_value", field.get("fieldValue"))
        )
        return (str(name) if name is not None else None, value)
    return None, field


def payload_to_dict(payload: Any) -> dict[str, Any]:
    """Converte payload de criação e payload retornado pela API para domínio.

    A API pode devolver ``field_values`` como lista de objetos
    ``{field_id, field_name, value}``; o domínio recebe um dicionário indexado
    pelo nome do campo.
    """
    payload = _dump(payload)
    if not isinstance(payload, Mapping):
        return {}
    data = dict(payload)
    fields = data.get("field_values")
    if fields is None:
        fields = data.get("fields")
    # O consumer da plataforma devolve cards lidos como envelope, com os
    # valores em `CARD_FIELDS` (em vez de `field_values`). Sem esta conversão,
    # o domínio recebe apenas metadados e ACAO_REQUERIDA fica vazia.
    if fields is None:
        fields = data.get("card_fields")
    if fields is None:
        fields = data.get("CARD_FIELDS")
    if fields is None:
        # Compatibilidade com modelos que serializam a chave em camelCase.
        fields = data.get("cardFields")
    if fields is None:
        return data
    fields = _dump(fields)
    # Algumas versões devolvem CARD_FIELDS como um envelope interno.
    if isinstance(fields, Mapping):
        for nested_key in ("field_values", "fields", "items", "values"):
            nested = fields.get(nested_key)
            if isinstance(nested, (Mapping, list, tuple)):
                fields = nested
                break
    if isinstance(fields, Mapping):
        # Pode vir como {NOME_DO_FIELD: valor}, ou como
        # {field_id: {field_name/name: ..., value: ...}}.
        if all(isinstance(value, Mapping) for value in fields.values()):
            normalized = {}
            for key, item in fields.items():
                name, value = _field_name_value(item)
                normalized[name or str(key)] = value
        else:
            normalized = dict(fields)
    else:
        normalized = {}
        for item in fields or []:
            name, value = _field_name_value(item)
            if name:
                normalized[name] = value
    # Metadados do envelope continuam acessíveis sem sobrescrever campos.
    for key in ("id", "title", "workflow_id", "phase_id"):
        if key in data and key not in normalized:
            normalized[key] = data[key]
    return normalized


def payload_from_transaction(transaction: Any, workflow_connector: Any) -> dict[str, Any]:
    """Obtém fields do resumo ou hidrata o item por ID.

    O endpoint de listagem usado pelo consumer pode devolver ``card_fields``
    como ``None``. Nesse caso, busca o detalhe do item sem criar outro card.
    """
    payload = transaction.payload
    parsed = payload_to_dict(payload)
    if parsed.get("ACAO_REQUERIDA") or parsed.get("acao_requerida"):
        return parsed

    item_id = str(transaction.id)
    # Preferir a operação pública do connector; não acoplar o domínio à
    # árvore interna do SDK oficial.
    fetch_detail = getattr(workflow_connector, "fetch_transaction_by_id", None)
    if callable(fetch_detail):
        detail = fetch_detail(item_id)
        hydrated = payload_to_dict(detail.payload if hasattr(detail, "payload") else detail)
        if hydrated.get("ACAO_REQUERIDA") or hydrated.get("acao_requerida"):
            return hydrated
    else:
        raise RuntimeError(
            "Connector não expõe fetch_transaction_by_id para hidratar o card."
        )

    hydrated = payload_to_dict(detail.payload if hasattr(detail, "payload") else detail)
    if not hydrated.get("ACAO_REQUERIDA") and not hydrated.get("acao_requerida"):
        logger.warning("Detalhe do card %s também não contém ACAO_REQUERIDA.", item_id)
    return hydrated
