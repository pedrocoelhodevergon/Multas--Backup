"""Erros da integração com Worksheets."""

from .client import WorksheetsApiError

__all__ = ["WorksheetsApiError"]
