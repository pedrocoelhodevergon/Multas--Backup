"""Adapter oficial síncrono para a API Worksheets da Ergon Platform.

O SDK oficial faz o fluxo API key -> access token automaticamente em
``POST /v1/auth/token``. Não enviar ``eks_...`` como Bearer: esse valor é o
client secret e deve ser passado como ``client_secret``.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Iterable
from typing import Any
from urllib.parse import urlsplit, urlunsplit

logger = logging.getLogger(__name__)


class WorksheetsApiError(RuntimeError):
    pass


def _platform_origin(url: str) -> str:
    """Converte base URL antiga (/api/v1/worksheets) no origin esperado pelo SDK."""
    parsed = urlsplit(url.rstrip("/"))
    path = parsed.path
    for suffix in ("/api/v1/worksheets", "/api/v1", "/worksheets"):
        if path.endswith(suffix):
            path = path[: -len(suffix)]
            break
    return urlunsplit((parsed.scheme, parsed.netloc, path.rstrip("/"), "", ""))


def _as_payload(response: Any) -> Any:
    """Extrai dados de respostas do SDK sem assumir um único envelope."""
    if isinstance(response, (dict, list)):
        return response
    if hasattr(response, "model_dump"):
        return response.model_dump()
    return response


class WorksheetsClient:
    def __init__(
        self,
        *,
        base_url: str | None = None,
        token: str | None = None,
        worksheet_id: str | None = None,
    ):
        configured_url = base_url or os.getenv(
            "WORKSHEETS_BASE_URL", "https://platform.ergondata.ai"
        )
        self.base_url = _platform_origin(configured_url)
        self.worksheet_id = worksheet_id or os.getenv(
            "WORKSHEET_ATIVOS_ID", "c495c649-11a1-4647-941b-fa5350ff64fc"
        )
        self._client = self._build_official_client(token)
        logger.info(
            "WorksheetsClient oficial configurado | worksheet_id=%s | base_url=%s",
            self.worksheet_id,
            self.base_url,
        )

    def _build_official_client(self, token: str | None) -> Any:
        try:
            from ergon_platform import ErgonClient
        except ImportError as exc:
            raise WorksheetsApiError(
                "SDK oficial ausente; instale ergon-platform-sdk (ou "
                "ergon-framework-python[ergon-platform])."
            ) from exc

        # Um JWT pré-obtido é aceito, mas um secret eks_... nunca é tratado como
        # token. Na configuração normal, o SDK troca client_id/client_secret.
        supplied = (token or "").removeprefix("Bearer ").strip()
        if supplied.count(".") == 2:
            return ErgonClient(
                token=supplied,
                company_id=os.getenv("ERGON_COMPANY_ID") or None,
                base_url=self.base_url,
            )

        client_id = os.getenv("ERGON_CLIENT_ID", "").strip()
        client_secret = os.getenv("ERGON_CLIENT_SECRET", "").strip()
        if not client_id or not client_secret:
            raise WorksheetsApiError(
                "Credenciais de API ausentes: configure ERGON_CLIENT_ID e "
                "ERGON_CLIENT_SECRET; o secret não deve ser usado como Bearer."
            )
        return ErgonClient(
            client_id=client_id,
            client_secret=client_secret,
            company_id=os.getenv("ERGON_COMPANY_ID") or None,
            base_url=self.base_url,
        )

    def _call(self, operation: str, *args: Any, collection: str = "worksheets", **kwargs: Any) -> Any:
        logger.debug("Worksheets SDK operation: %s.%s", collection, operation)
        try:
            if collection == "root":
                # No SDK 0.2.x/0.3.x, `client.worksheets.worksheets` monta
                # erroneamente /api/v1/worksheets/worksheets. Usamos o
                # request oficial do próprio transport, preservando a
                # autenticação, retries e tratamento de erros do SDK.
                method, path = args[0], args[1]
                result = self._client.worksheets.request(method, path, **kwargs)
            else:
                target = getattr(self._client.worksheets, collection)
                result = getattr(target, operation)(*args, **kwargs)
            logger.debug("Worksheets SDK success: %s.%s", collection, operation)
            return _as_payload(result)
        except Exception as exc:  # SDK exceptions vary by version
            logger.error("Worksheets SDK error: %s.%s: %s", collection, operation, exc)
            raise WorksheetsApiError(
                f"Falha em Worksheets ({collection}.{operation}): {exc}"
            ) from exc

    def list_columns(self) -> list[dict[str, Any]]:
        payload = self._call("columns", self.worksheet_id)
        if isinstance(payload, dict):
            return payload.get("columns", payload.get("items", []))
        return payload or []

    def bulk_create_rows(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if len(rows) > 1000:
            raise ValueError("A API Worksheets aceita no máximo 1.000 rows por lote.")
        logger.info("Worksheets bulk create | rows=%d", len(rows))
        payload = self._call("bulk_rows", self.worksheet_id, data={"rows": rows})
        return payload if isinstance(payload, list) else payload.get("rows", payload) if isinstance(payload, dict) else []

    def patch_row(self, row_id: str, cell_values: list[dict[str, Any]]) -> dict[str, Any]:
        payload = self._call(
            "update", row_id, data={"cell_values": cell_values}, collection="rows"
        )
        return payload if isinstance(payload, dict) else {}

    def query_rows(
        self,
        *,
        filters: list[dict[str, Any]] | None = None,
        cursor: str | None = None,
        limit: int = 1000,
    ) -> dict[str, Any]:
        if not 1 <= limit <= 1000:
            raise ValueError("limit deve estar entre 1 e 1.000")
        body: dict[str, Any] = {"filters": filters or [], "limit": limit, "include_total": False}
        if cursor:
            body["cursor"] = cursor
        logger.debug("Worksheets query rows | limit=%d | cursor=%s", limit, bool(cursor))
        payload = self._call("query_rows", self.worksheet_id, data=body)
        return payload if isinstance(payload, dict) else {}

    def iter_rows(self, *, filters: list[dict[str, Any]] | None = None) -> Iterable[dict[str, Any]]:
        cursor = None
        page_number = 0
        while True:
            page_number += 1
            page = self.query_rows(filters=filters, cursor=cursor)
            rows = page.get("rows", [])
            logger.debug(
                "Worksheet page=%d rows=%d has_next=%s",
                page_number,
                len(rows),
                bool(page.get("next_cursor")),
            )
            yield from rows
            cursor = page.get("next_cursor")
            if not rows or not cursor:
                return
