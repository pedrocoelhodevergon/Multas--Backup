"""Mapeamento entre registros SAP e rows do Worksheet."""

from __future__ import annotations

from datetime import date
from typing import Any

from atualizacao_ativos.tasks.auditoria_inativacoes.schemas import RegistroSap
from atualizacao_ativos.tasks.auditoria_inativacoes.rules import normalizar_placa, gerar_variacao_mercosul_antiga


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"true", "1", "sim", "ativo", "yes"}


def worksheet_row_to_registro_sap(row: dict[str, Any]) -> RegistroSap:
    """Converte uma row do Worksheet no modelo de domínio do cruzamento."""
    values: dict[str, Any] = {}
    for cell in row.get("cell_values", []):
        name = cell.get("column_name") or cell.get("name")
        if name:
            values[name] = cell.get("value")

    placa = normalizar_placa(str(values.get("placa") or ""))
    if not placa:
        raise ValueError(f"Row {row.get('id', '<sem-id>')} do Worksheet sem placa")

    return RegistroSap(
        placa=placa,
        is_active=_as_bool(values.get("is_active_sap")),
        status_bruto=str(values.get("status_sap") or ""),
        cc=str(values.get("centro_custo_sap") or ""),
        codigo_empresa=str(values.get("codigo_empresa_sap") or ""),
        empresa=str(values.get("empresa_sap") or ""),
        renavam=str(values.get("renavam") or ""),
        chassi=str(values.get("chassi") or ""),
        cnpj="".join(c for c in str(values.get("cnpj_sap") or "") if c.isdigit()),
    )


def registro_sap_to_row(registro: RegistroSap, *, origem: str, data_carga: date | None = None) -> dict[str, Any]:
    placa = normalizar_placa(registro.placa)
    return {
        "chave_sap": f"{registro.codigo_empresa}|{placa}",
        "placa": placa,
        "placa_mercosul": gerar_variacao_mercosul_antiga(placa) or None,
        "codigo_empresa_sap": registro.codigo_empresa,
        "empresa_sap": registro.empresa or None,
        "cnpj_sap": registro.cnpj or None,
        "status_sap": registro.status_bruto or None,
        "is_active_sap": registro.is_active,
        "centro_custo_sap": registro.cc or None,
        "data_carga_sap": (data_carga or date.today()).isoformat(),
        "origem_sap": origem,
        "chassi": registro.chassi or None,
        "renavam": registro.renavam or None,
    }
