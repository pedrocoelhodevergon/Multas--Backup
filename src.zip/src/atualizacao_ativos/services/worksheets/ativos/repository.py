"""Operações do Worksheet de Ativos."""

from __future__ import annotations

import logging
from collections.abc import Iterable
from typing import Any

from ..client import WorksheetsClient

logger = logging.getLogger(__name__)
from .constants import COLUMN_NAMES, REQUIRED_COLUMNS, WORKSHEET_BULK_SIZE, WORKSHEET_QUERY_PAGE_SIZE


class AtivosWorksheetRepository:
    def __init__(self, client: WorksheetsClient | None = None):
        self.client = client or WorksheetsClient()
        self.columns: dict[str, str] = {}

    def validate_schema(self) -> None:
        columns = self.client.list_columns()
        self.columns = {str(c["name"]): str(c["id"]) for c in columns}
        missing = set(COLUMN_NAMES) - self.columns.keys()
        if missing:
            raise RuntimeError(f"Worksheet de Ativos sem colunas: {sorted(missing)}")
        invalid_required = {
            name for name in REQUIRED_COLUMNS
            if not next(c for c in columns if c["name"] == name).get("required")
        }
        if invalid_required:
            raise RuntimeError(f"Colunas obrigatórias incorretamente configuradas: {sorted(invalid_required)}")

    def _cells(self, values: dict[str, Any]) -> list[dict[str, Any]]:
        if not self.columns:
            self.validate_schema()
        return [
            {"column_id": self.columns[name], "value": value}
            for name, value in values.items()
            if name in self.columns and value is not None
        ]

    def create_rows(self, values: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
        batch: list[dict[str, Any]] = []
        created: list[dict[str, Any]] = []
        for item in values:
            batch.append({"cell_values": self._cells(item)})
            if len(batch) == WORKSHEET_BULK_SIZE:
                created.extend(self.client.bulk_create_rows(batch))
                batch = []
        if batch:
            created.extend(self.client.bulk_create_rows(batch))
        return created

    def rows(self, *, filters: list[dict[str, Any]] | None = None) -> Iterable[dict[str, Any]]:
        return self.client.iter_rows(filters=filters)

    @staticmethod
    def _row_values(row: dict[str, Any]) -> dict[str, Any]:
        values = {}
        for cell in row.get("cell_values", []):
            name = cell.get("column_name") or cell.get("name")
            if name:
                values[name] = cell.get("value")
        return values

    def upsert_sap_rows(
        self,
        values: Iterable[dict[str, Any]],
        existing_index: dict[str, dict[str, Any]] | None = None,
    ) -> dict[str, int]:
        """Atualiza pela chave_sap e cria somente rows novas.

        Se ``existing_index`` não for fornecido, carrega todas as rows do
        Worksheet (comportamento O(N) por chamada). Para processar múltiplas
        rows em lote, passe o índice pré-carregado para evitar O(N²).
        """
        if not self.columns:
            self.validate_schema()
        if existing_index is None:
            existing_index = {
                self._row_values(row).get("chave_sap"): row
                for row in self.client.iter_rows()
                if self._row_values(row).get("chave_sap")
            }
        pending: list[dict[str, Any]] = []
        updated = 0
        for item in values:
            key = item.get("chave_sap")
            row = existing_index.get(key)
            if row:
                current = self._row_values(row)
                # data_carga_sap é metadado da execução e muda diariamente;
                # não deve provocar PATCH quando os dados SAP não mudaram.
                changed = any(
                    item.get(name) != current.get(name)
                    for name in item
                    if name != "data_carga_sap"
                )
                if changed:
                    self.patch(str(row["id"]), item)
                    updated += 1
            else:
                pending.append({"cell_values": self._cells(item)})
        created = 0
        for start in range(0, len(pending), WORKSHEET_BULK_SIZE):
            created += len(self.client.bulk_create_rows(pending[start:start + WORKSHEET_BULK_SIZE]))
        logger.info(
            "Worksheet SAP upsert concluído | existentes=%d | alteradas=%d | novas=%d",
            len(existing_index),
            updated,
            created,
        )
        return {"created": created, "updated": updated}

    def load_existing_index(self) -> dict[str, dict[str, Any]]:
        """Carrega o índice de chave_sap → row de todas as rows do Worksheet.

        Usado para evitar O(N²) quando processar múltiplas rows em lote.
        """
        if not self.columns:
            self.validate_schema()
        return {
            self._row_values(row).get("chave_sap"): row
            for row in self.client.iter_rows()
            if self._row_values(row).get("chave_sap")
        }

    def patch(self, row_id: str, values: dict[str, Any]) -> dict[str, Any]:
        return self.client.patch_row(row_id, self._cells(values))

    def patch_if_changed(
        self,
        row: dict[str, Any],
        values: dict[str, Any],
        *,
        ignore_fields: set[str] | None = None,
    ) -> bool:
        """Faz PATCH apenas quando algum valor efetivamente mudou."""
        current = self._row_values(row)
        ignored = ignore_fields or set()
        changed = any(
            values.get(name) != current.get(name)
            for name in values
            if name not in ignored
        )
        if not changed:
            return False
        self.patch(str(row["id"]), values)
        return True
