"""Contrato lógico do Worksheet de Ativos."""

import os

WORKSHEET_ATIVOS_ID = os.getenv(
    "WORKSHEET_ATIVOS_ID",
    "c495c649-11a1-4647-941b-fa5350ff64fc",
)
WORKSHEET_BULK_SIZE = 1000
WORKSHEET_QUERY_PAGE_SIZE = 1000
LW_QUERY_BATCH_SIZE = 500

COLUMN_NAMES = (
    "chave_sap", "placa", "placa_mercosul", "id_lw",
    "codigo_empresa_sap", "empresa_sap", "cnpj_sap", "status_sap",
    "is_active_sap", "centro_custo_sap", "data_carga_sap", "origem_sap",
    "chassi", "renavam", "marca_modelo", "ano_fabricacao",
    "status_frota_lw", "centro_custo_lw", "data_ultima_sincronizacao",
)

REQUIRED_COLUMNS = {"chave_sap", "placa", "codigo_empresa_sap", "data_carga_sap", "origem_sap"}
