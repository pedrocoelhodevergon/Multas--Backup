"""CLI de produção do domínio Atualização de Ativos.

Este módulo é o entrypoint oficial das tasks Ergon de Ativos. Ele entrega ao
CLI do framework as quatro `TaskConfig` registradas no domínio; não executa o
runner local interativo (`tasks/run.py`).

Uso:
    ENV_FILE=.env python -m atualizacao_ativos.cli list
    ENV_FILE=.env python -m atualizacao_ativos.cli run extracao-sap
    ENV_FILE=.env python -m atualizacao_ativos.cli run cruzamento-ativos
    ENV_FILE=.env python -m atualizacao_ativos.cli run execucao-lw
    ENV_FILE=.env python -m atualizacao_ativos.cli run relatorio-ativos

No Windows PowerShell:
    $env:ENV_FILE = ".env"
    $env:PYTHONPATH = "src"
    python -m atualizacao_ativos.cli list
"""

from __future__ import annotations

from ergon.cli import ergon

from atualizacao_ativos.tasks import TASKS


def main() -> None:
    """Inicia o CLI do framework com as tasks de Atualização de Ativos."""
    ergon(TASKS)


if __name__ == "__main__":
    main()
