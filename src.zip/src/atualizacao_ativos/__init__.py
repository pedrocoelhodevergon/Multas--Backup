"""Domínio de atualização de ativos.

O carregamento do `.env` acontece aqui, antes do registro/import das tasks.
Isso é necessário porque o framework Ergon valida suas configurações durante
os imports de `tasks`, antes de `tasks/run.py` executar seu corpo.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import find_dotenv, load_dotenv

_env_file = os.getenv("ENV_FILE")
if _env_file:
    _env_path = Path(_env_file)
    if not _env_path.is_absolute():
        _env_path = Path.cwd() / _env_path
    load_dotenv(_env_path, override=False)
else:
    _env_path = find_dotenv(usecwd=True)
    if _env_path:
        load_dotenv(_env_path, override=False)
