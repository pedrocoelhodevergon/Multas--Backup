"""Task `execucao_lw` — aplicação de ações diretas na LW V2.

Responsabilidade única: executar a ação requerida (Inativar / Reativar /
Mobilizar Centro de Custo) diretamente na LW, a partir de um item de auditoria.

> CONSUMIDORA no framework: consome cards já roteados para `Execução
> Automática - LW`, executa a ação na LW e usa o ack/nack configurado para
> `Finalizado`/`Erros`. Casos explicitamente humanos são enviados para
> `Validação Humana`.
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from ergon import connector, task

from atualizacao_ativos.connectors.lw import LwConnector
from atualizacao_ativos.tasks import settings
from atualizacao_ativos.services.ergon_payload import payload_from_transaction
from atualizacao_ativos.tasks.auditoria_inativacoes.constants import ELIMINAR_PLACA
from atualizacao_ativos.tasks.auditoria_inativacoes.rules import normalizar_placa

logger = logging.getLogger(__name__)


class ExecucaoLwTask(task.mixins.ConsumerTask):
    """Executa ações automáticas (escrita) na LW V2."""

    lw_service: LwConnector
    workflow_connector: connector.Connector
    consumer_policy: task.policies.ConsumerPolicy

    def __init__(self, connector: LwConnector | None = None, **kwargs) -> None:
        if connector is not None:
            self.lw_service = connector
            self.connector = connector

    # ------------------------------------------------------------------
    # Hooks do contrato do framework
    # ------------------------------------------------------------------

    def process_transaction(self, transaction: connector.Transaction) -> dict:
        raw_payload = transaction.payload.model_dump() if hasattr(transaction.payload, "model_dump") else transaction.payload
        raw_payload = raw_payload if isinstance(raw_payload, dict) else {}
        raw_card_fields = (
            raw_payload.get("CARD_FIELDS")
            or raw_payload.get("card_fields")
            or raw_payload.get("cardFields")
        )
        if isinstance(raw_card_fields, dict):
            raw_field_keys = list(raw_card_fields.keys())[:20]
            raw_field_entry_keys = [
                list(value.keys())[:10]
                for value in raw_card_fields.values()
                if isinstance(value, dict)
            ][:5]
        elif isinstance(raw_card_fields, list):
            raw_field_keys = [type(value).__name__ for value in raw_card_fields[:20]]
            raw_field_entry_keys = [
                list(value.keys())[:10]
                for value in raw_card_fields[:5]
                if isinstance(value, dict)
            ]
        else:
            raw_field_keys = []
            raw_field_entry_keys = []
        logger.info(
            "[DEBUG-PAYLOAD] raw_keys=%s | CARD_FIELDS_type=%s | CARD_FIELDS_keys=%s | entry_keys=%s",
            sorted(str(key) for key in raw_payload.keys()),
            type(raw_card_fields).__name__,
            raw_field_keys,
            raw_field_entry_keys,
        )
        # O card na plataforma é a única fonte de verdade; não usar estado
        # local anterior para reconstruir uma transação.
        parsed_item = payload_from_transaction(transaction, self.workflow_connector)
        logger.info(
            "[DEBUG-PAYLOAD] origem=card | parsed_keys=%s",
            sorted(str(key) for key in parsed_item.keys()),
        )
        item = {str(key).upper(): value for key, value in parsed_item.items()}
        # Nunca consultar/escrever na LW com um envelope sem os campos do card.
        # Isso ocorre quando a API devolve `CARD_FIELDS` e ele não é extraído.
        if not item.get("ACAO_REQUERIDA"):
            raise task.exceptions.NonRetryableException(
                message="Card sem ACAO_REQUERIDA após normalização do payload; execução bloqueada."
            )
        if not (
            item.get("PLACA_REGISTRADA_LW")
            or item.get("PLACA_CRUZADA_SAP")
            or item.get("PLACA")
        ):
            raise task.exceptions.NonRetryableException(
                message="Card sem placa após normalização do payload; execução bloqueada."
            )
        if os.getenv("LW_WRITE_ENABLED", "false").lower() != "true":
            raise task.exceptions.NonRetryableException(
                message="Escrita na LW bloqueada: defina LW_WRITE_ENABLED=true após validação."
            )
        ok, msg = self.executar(item)
        human_review = self._requires_human_review(item, ok, msg)
        if not ok and not human_review:
            raise task.exceptions.NonRetryableException(message=msg)
        resultado = {
            "item": item,
            "ok": ok,
            "requires_human_review": human_review,
            "mensagem": msg,
            "field_values": self._execution_field_values(item, ok, msg),
        }
        # O resultado será persistido no mesmo card por
        # update_transaction() antes do ack/nack; não gravar estado paralelo.
        return resultado

    @staticmethod
    def _execution_field_values(item: dict, ok: bool, message: str) -> dict[str, str]:
        """Campos que devem aparecer no card depois da execução na LW."""
        acao = str(item.get("ACAO_REQUERIDA", "")).upper()
        if "CENTRO DE CUSTO" in acao:
            anterior = item.get("CENTRO_CUSTO_ATUAL_LW", "")
            novo = item.get("CENTRO_CUSTO_SAP", "")
        elif "REATIVAR" in acao:
            anterior, novo = item.get("STATUS_NA_LW", ""), "ATIVO"
        elif "INATIVA" in acao:
            anterior, novo = item.get("STATUS_NA_LW", ""), "INATIVO"
        else:
            anterior = item.get("VALOR_ANTERIOR", "")
            novo = item.get("VALOR_NOVO", "")
        timestamp = datetime.now(timezone.utc).isoformat()
        log = (
            f"[{timestamp}] {'SUCESSO' if ok else 'FALHA'} - EXECUÇÃO NA LW\\n"
            f"Ação: {acao}\\nPlaca: {item.get('PLACA_REGISTRADA_LW') or item.get('PLACA_CRUZADA_SAP', '')}\\n"
            f"Valor anterior: {anterior}\\nValor novo: {novo}\\nRetorno: {message}"
        )
        return {
            "VALOR_ANTERIOR": str(anterior or ""),
            "VALOR_NOVO": str(novo or ""),
            "MENSAGEM_RETORNO_LW": str(message),
            "ID_GERADO_LW": str(item.get("ID_VEICULO_LW", "") or ""),
            "LOG_EXECUCAO_LW": log,
            "LOG_EXECUCAO": log,
            "TRACEBACK_LOG / LOG_EXECUCAO": log,
            "STATUS_EXECUCAO": "SUCESSO" if ok else "ERRO",
            "STATUS_PROCESSAMENTO": "CONCLUIDO" if ok else "ERRO",
            "DATA_PROCESSAMENTO": timestamp,
        }

    def _persist_execution_fields(self, transaction, result: dict) -> None:
        """Persiste no mesmo card usando o SDK oficial, sem alterar o framework."""
        field_values = result.get("field_values", {})

        # Compatibilidade caso alguma versão do connector já exponha o wrapper.
        update_transaction = getattr(self.workflow_connector, "update_transaction", None)
        if callable(update_transaction):
            update_transaction(transaction, field_values=field_values)
            return

        # O framework não expõe update_transaction(), mas disponibiliza o
        # client oficial. O SDK 0.3.x herda update() de Collection.
        client = getattr(self.workflow_connector, "client", None)
        items_api = getattr(getattr(client, "workflows", None), "items", None)
        if items_api is None:
            raise RuntimeError(
                "Connector não expõe client.workflows.items para atualizar o card."
            )

        updater = getattr(items_api, "update", None)
        if not callable(updater):
            updater = getattr(items_api, "update_item", None)
        if not callable(updater):
            raise RuntimeError(
                "SDK de Workflows não expõe items.update nem items.update_item."
            )

        logger.info(
            "Atualizando fields do card %s via SDK antes do ack.",
            transaction.id,
        )
        updater(transaction.id, field_values=field_values)

    def handle_process_success(self, transaction: connector.Transaction, result: dict) -> None:
        self._persist_execution_fields(transaction, result)
        if result.get("requires_human_review"):
            self.workflow_connector.ack_transaction(
                transaction,
                phase_id=settings.WORKFLOW_CONFIG.fase_validacao_humana,
            )
            return
        self.workflow_connector.ack_transaction(transaction)

    @staticmethod
    def _requires_human_review(item: dict, ok: bool, message: str) -> bool:
        """Identifica resultados que não são falha técnica, mas decisão humana.

        Ações sem automação direta exigem decisão humana. Falhas na criação
        do centro de custo são falhas técnicas e seguem para `Erros`.
        """
        if str(message).upper().startswith("VALIDACAO_HUMANA:"):
            return True
        if not ok and str(item.get("ACAO_REQUERIDA", "")).upper() not in {
            "INATIVAÇÃO",
            "INATIVACAO",
            "REATIVAR",
            "ALTERAÇÃO DE CENTRO DE CUSTO",
            "ALTERACAO DE CENTRO DE CUSTO",
        }:
            return True
        return False

    def handle_process_exception(self, transaction: connector.Transaction, exception: Exception) -> None:
        self.workflow_connector.nack_transaction(transaction, requeue=False)

    def execute(self) -> None:
        self.consume_transactions(self.consumer_policy)

    # ------------------------------------------------------------------
    # Lógica de negócio (preservada intacta do original)
    # ------------------------------------------------------------------

    def executar(self, item_auditoria: dict) -> tuple[bool, str]:
        """Executa a ação direta na LW. Retorna `(ok, mensagem)`."""
        placa = item_auditoria.get("PLACA_REGISTRADA_LW")
        if not placa or str(placa).strip() in ELIMINAR_PLACA:
            placa = item_auditoria.get("PLACA_CRUZADA_SAP") or item_auditoria.get("PLACA")
        placa = normalizar_placa(placa)

        acao = str(item_auditoria.get("ACAO_REQUERIDA", "")).upper()
        cc_sap = str(
            item_auditoria.get("CENTRO_CUSTO_SAP")
            or item_auditoria.get("CENTRO_DE_CUSTO")
            or ""
        ).strip()

        id_veiculo = item_auditoria.get("ID_VEICULO_LW")

        logger.info(
            "[DEBUG-EXECUCAO-LW] acao=%r | placa=%r | cc_sap=%r | id_veiculo=%r | keys=%s",
            acao, placa, cc_sap, id_veiculo, sorted(item_auditoria.keys()),
        )

        if not id_veiculo:
            veiculo = self.lw_service.consultar_veiculo_por_placa(placa)
            if not veiculo:
                logger.warning("[DEBUG-EXECUCAO-LW] veículo %r não localizado na LW.", placa)
                return False, f"Veículo {placa} não localizado na LW para capturar o ID."
            id_veiculo = veiculo.id
            logger.info("[DEBUG-EXECUCAO-LW] ID_VEICULO_LW resolvido via consulta por placa -> %r", id_veiculo)

        try:
            if "INATIVA" in acao:
                logger.info("[DEBUG-EXECUCAO-LW] Chamando inativar_veiculos_v2(%r)", id_veiculo)
                return self.lw_service.inativar(id_veiculo)
            if "REATIVAR" in acao:
                logger.info("[DEBUG-EXECUCAO-LW] Chamando ativar_veiculos_v2(%r)", id_veiculo)
                return self.lw_service.ativar(id_veiculo)
            if "CENTRO DE CUSTO" in acao or "ALTERAR_CC" in acao:
                logger.info("[DEBUG-EXECUCAO-LW] Buscando id_grupo para cc_sap=%r", cc_sap)
                mapa = self.lw_service.carregar_dicionario_grupos()
                id_grupo = mapa.get(cc_sap)
                if not id_grupo:
                    logger.info("[DEBUG-EXECUCAO-LW] Centro de custo %r ausente; tentando criar pela API V2.", cc_sap)
                    criado, id_grupo, detalhe = self.lw_service.criar_centro_custo(
                        centro_custo=cc_sap,
                        cnpj=item_auditoria.get("CNPJ_SAP", ""),
                        nome_empresa=item_auditoria.get("EMPRESA_NO_SAP", ""),
                    )
                    if not criado or not id_grupo:
                        logger.error("[DEBUG-EXECUCAO-LW] Criação do centro de custo falhou: %s", detalhe)
                        return False, f"ERRO_CRIACAO_CENTRO_CUSTO: {detalhe}"
                    logger.info("[DEBUG-EXECUCAO-LW] Centro de custo criado/encontrado: id=%r | %s", id_grupo, detalhe)
                logger.info("[DEBUG-EXECUCAO-LW] Mobilizar(id_veiculo=%r, id_grupo=%r)", id_veiculo, id_grupo)
                return self.lw_service.mobilizar_centro_custo(id_veiculo, id_grupo)
            logger.warning("[DEBUG-EXECUCAO-LW] Ação %r sem automação direta (vai p/ validação humana).", acao)
            return False, f"Ação '{acao}' não possui automação direta mapeada."
        except Exception as e:  # noqa: BLE001
            logger.exception("[DEBUG-EXECUCAO-LW] Erro na requisição LW.")
            return False, f"Erro na requisição da LW: {e}"
