"""Configuração do consumer de execução na LW."""
from __future__ import annotations
from ergon import task
from atualizacao_ativos.tasks import settings
from atualizacao_ativos.tasks.policies import consumer_policy
from atualizacao_ativos.tasks.execucao_lw.task import ExecucaoLwTask

TASK_SLUG = "execucao-lw"

TASK_EXECUCAO_LW = task.TaskConfig(
    name="execucao-lw",
    task=ExecucaoLwTask,
    connectors={"workflow": settings.platform_consumer_connector(
        settings.WORKFLOW_CONFIG.workflow_id,
        settings.WORKFLOW_CONFIG.fase_ea_lw,
        settings.WORKFLOW_CONFIG.fase_relatorio,
        settings.WORKFLOW_CONFIG.fase_erros,
        # Os cards da tela estão atribuídos a `key-att-ativos`; permitir que
        # este consumer também leia cards atribuídos evita um fetch vazio.
        unassigned=False,
    )},
    services={"lw": settings.LW_CONNECTOR},
    policies=[consumer_policy("execucao-lw", "TASK_POLICY_EXECUCAO_LW")],
    logging=settings.LOGGING,
    tracing=settings.TRACING,
)
task.manager.register(TASK_EXECUCAO_LW)
