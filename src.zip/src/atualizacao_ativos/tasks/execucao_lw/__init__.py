"""Task `execucao_lw` (consumidora): aplicação de ações diretas na LW V2."""

from __future__ import annotations

from atualizacao_ativos.tasks.execucao_lw.config import TASK_EXECUCAO_LW, TASK_SLUG
from atualizacao_ativos.tasks.execucao_lw.task import ExecucaoLwTask

__all__ = ["ExecucaoLwTask", "TASK_EXECUCAO_LW", "TASK_SLUG"]
