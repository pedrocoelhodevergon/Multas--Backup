"""Task `relatorio_ativos` — consolidação do relatório xlsx (Etapa 4).

Responsabilidade única: a cada card consumido, consultar a plataforma por
todos os cards do mesmo LOTE_ID e gerar o relatório xlsx consolidado. O
relatório final (último card processado) contém todos os registros do lote.

> CONSUMIDORA no framework: consome os cards da fase de relatório e grava o
> relatório xlsx consolidado (fase de finalização). Injeta `lw` via services.
"""

from __future__ import annotations

import logging
from typing import Any, List, Optional

from ergon import connector, task

from atualizacao_ativos.connectors.lw import LwConnector
from atualizacao_ativos.services.ergon_payload import payload_from_transaction, payload_to_dict
from atualizacao_ativos.tasks import settings
from atualizacao_ativos.tasks.auditoria_inativacoes.schemas import ResultadoAuditoria

logger = logging.getLogger(__name__)


class RelatorioAtivosTask(task.mixins.ConsumerTask):
    """Grava o relatório consolidado de auditoria xlsx por LOTE_ID."""

    lw_service: LwConnector
    workflow_connector: connector.Connector
    consumer_policy: task.policies.ConsumerPolicy

    def __init__(self, connector: LwConnector | None = None, **kwargs) -> None:
        if connector is not None:
            self.lw_service = connector
            self.connector = connector

    # ------------------------------------------------------------------
    # Hooks do contrato do framework
    # ------------------------------------------------------------------

    def process_transaction(self, transaction: connector.Transaction) -> dict:
        # O card é a única fonte de verdade; não ler execution_results nem
        # reconstruir lote a partir de arquivos locais.
        payload = payload_from_transaction(transaction, self.workflow_connector)
        lote_id = str(
            payload.get("LOTE_ID")
            or payload.get("lote_id")
            or "sem-lote"
        )
        expected = int(
            payload.get("LOTE_TOTAL")
            or payload.get("lote_total")
            or 0
        )

        # Busca todos os cards do lote na plataforma para gerar o relatório
        # consolidado. Inclui cards de todas as fases (Resultado Cruzamento,
        # Validação Humana, Execução Automática, Relatório de Ativos).
        payloads_do_lote = self._buscar_cards_do_lote(lote_id)
        resultados = self._payloads_to_resultados(payloads_do_lote)

        if not resultados:
            # Fallback: se a consulta não retornou nada, usa o card atual.
            item = {str(key).lower(): value for key, value in payload.items()}
            resultados = [ResultadoAuditoria.model_validate(item)]

        # Log de progresso do lote
        completo = "COMPLETO" if len(resultados) >= expected else "incompleto"
        logger.info(
            "Relatório do lote %s: %d/%d cards encontrados na plataforma (%s).",
            lote_id, len(resultados), expected, completo,
        )

        # Gera relatório com os cards disponíveis. O relatório final (quando
        # len(resultados) == expected) contém todos os cards do lote.
        caminho = self.executar(resultados)
        return {"caminho": caminho, "lote_id": lote_id, "linhas": len(resultados)}

    def handle_process_success(self, transaction: connector.Transaction, result: dict) -> None:
        self.workflow_connector.ack_transaction(transaction)

    def handle_process_exception(self, transaction: connector.Transaction, exception: Exception) -> None:
        self.workflow_connector.nack_transaction(transaction, requeue=False)

    def execute(self, resultados: Optional[List[ResultadoAuditoria]] = None) -> Optional[str]:
        if resultados is not None:
            return self.executar(resultados)
        if self.connectors:
            self.consume_transactions(self.consumer_policy)
            return None
        logger.info("RelatorioAtivosTask sem dados nem connectors — nada a gerar (debug).")
        return None

    # ------------------------------------------------------------------
    # Consolidação do lote via plataforma
    # ------------------------------------------------------------------

    def _buscar_cards_do_lote(self, lote_id: str) -> list[dict]:
        """Busca todos os cards do lote no workflow via SDK oficial.

        Pagina pelos itens do workflow, hidrata cada item via ``scope.item()``
        para obter os fields completos (``scope.items()`` retorna apenas
        ``card_fields`` com ``show_on_card=true``). Filtra por LOTE_ID em
        Python. Se o client estiver indisponível ou a consulta falhar, retorna
        vazio.
        """
        client = getattr(self.workflow_connector, "client", None)
        if client is None:
            logger.warning("Client do workflow_connector indisponível para consolidação do lote.")
            return []
        try:
            scope = client.workflows.workflow(settings.WORKFLOW_CONFIG.workflow_id)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Falha ao obter scope do workflow para consolidação: %s", exc)
            return []
        cards: list[dict] = []
        offset = 0
        page_size = 500
        while True:
            try:
                response = scope.items(limit=page_size, offset=offset)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Consolidação do lote %s: falha ao listar itens (offset=%d): %s",
                    lote_id, offset, exc,
                )
                break
            items = _items_from_response(response)
            if not items:
                break
            for item in items:
                # Extrai fields do resumo
                parsed = payload_to_dict(item)
                # Se LOTE_ID não está no resumo (show_on_card=false), hidratar
                if not parsed.get("LOTE_ID"):
                    try:
                        item_id = item.get("id") if isinstance(item, dict) else getattr(item, "id", None)
                        if item_id:
                            # Busca o item completo via SDK
                            # O SDK oficial expõe scope.item(item_id) para hidratar
                            full_item = scope.item(item_id)
                            parsed = payload_to_dict(full_item)
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "Consolidação: falha ao hidratar item %s: %s",
                            item_id, exc,
                        )
                        continue
                item_lote = str(parsed.get("LOTE_ID", "")).strip()
                if item_lote == str(lote_id).strip():
                    cards.append(parsed)
            if len(items) < page_size:
                break
            offset += page_size
        return cards

    def _payloads_to_resultados(self, payloads: list[dict]) -> list[ResultadoAuditoria]:
        """Converte payloads normalizados em ResultadoAuditoria, ignorando inválidos."""
        resultados: list[ResultadoAuditoria] = []
        for payload in payloads:
            item = {str(key).lower(): value for key, value in payload.items()}
            try:
                resultados.append(ResultadoAuditoria.model_validate(item))
            except (TypeError, ValueError) as exc:
                logger.warning("Card do lote ignorado no relatório: %s", exc)
        return resultados

    # ------------------------------------------------------------------
    # Lógica de negócio (preservada intacta do original)
    # ------------------------------------------------------------------

    def executar(self, resultados: List[ResultadoAuditoria]) -> Optional[str]:
        logger.info("[ETAPA 4] Gravando relatório xlsx consolidado com %d registros...", len(resultados))
        caminho = self.lw_service.salvar_relatorio(resultados)
        return caminho


def _items_from_response(response: Any) -> list[Any]:
    """Extrai a lista de itens de uma resposta do SDK."""
    if hasattr(response, "model_dump"):
        response = response.model_dump()
    if isinstance(response, list):
        return response
    if isinstance(response, dict):
        for key in ("items", "data", "results"):
            value = response.get(key)
            if isinstance(value, list):
                return value
    return []
