"""Configuração do consumer de relatório de ativos."""
from __future__ import annotations
from ergon import task
from atualizacao_ativos.tasks import settings
from atualizacao_ativos.tasks.policies import consumer_policy
from atualizacao_ativos.tasks.relatorio_ativos.task import RelatorioAtivosTask

TASK_SLUG = "relatorio-ativos"

TASK_RELATORIO_ATIVOS = task.TaskConfig(
    name="relatorio-ativos",
    task=RelatorioAtivosTask,
    connectors={"workflow": settings.platform_consumer_connector(
        settings.WORKFLOW_CONFIG.workflow_id,
        settings.WORKFLOW_CONFIG.fase_relatorio,
        settings.WORKFLOW_CONFIG.fase_finalizado,
        settings.WORKFLOW_CONFIG.fase_erros,
        unassigned=False,
    )},
    services={"lw": settings.LW_CONNECTOR},
    policies=[consumer_policy("relatorio", "TASK_POLICY_RELATORIO")],
    logging=settings.LOGGING,
    tracing=settings.TRACING,
)
task.manager.register(TASK_RELATORIO_ATIVOS)
