"""Task `relatorio_ativos` (consumidora): gravação do relatório xlsx."""

from __future__ import annotations

from atualizacao_ativos.tasks.relatorio_ativos.config import TASK_RELATORIO_ATIVOS, TASK_SLUG
from atualizacao_ativos.tasks.relatorio_ativos.task import RelatorioAtivosTask

__all__ = ["RelatorioAtivosTask", "TASK_RELATORIO_ATIVOS", "TASK_SLUG"]
