"""Runner local interativo — Atualização de Ativos (SAP -> LW).

Igual ao antigo `tasks/run.py`: dá as OPÇÕES de qual task rodar (ou o fluxo
completo) e BATE NAS APIs REAIS (planilhas SAP + API LW) usando credenciais do `.env`.
Sem mock.

Uso:
    ENV_FILE=.env python -m atualizacao_ativos.tasks.run
"""

from __future__ import annotations

import logging
import os

from dotenv import find_dotenv, load_dotenv

os.environ["ENV_FILE"] = ".env"
load_dotenv(find_dotenv())

from assets.task_runner import instantiate_task  # noqa: E402
from atualizacao_ativos.tasks import settings  # noqa: E402  (registra logging/config)

logger = logging.getLogger("ATIVOS_RUNNER")

ORDER = ["extracao-sap", "cruzamento-ativos", "roteamento-cruzamento", "execucao-lw"]
SAP_BASE_DIR = os.getenv("SAP_BASE_DIR", "assets/planilhas_sap")


def _by_slug(slug: str):
    from atualizacao_ativos.tasks import TASKS

    for cfg in TASKS:
        if cfg.name == slug:
            return cfg
    return None


def _menu() -> str:
    print("\n===== RUNNER ATIVOS (MC01/MC02: SAP->LW) — APIs REAIS =====")
    print("  [0] fluxo completo (SAP -> Worksheet -> cruzamento -> roteamento -> execução)")
    for i, slug in enumerate(ORDER, start=1):
        print(f"  [{i}] {slug}")
    print("  [q] sair")
    return input("Escolha: ").strip().lower()


def _to_upper_dict(model) -> dict:
    if hasattr(model, "model_dump"):
        return {str(k).upper(): v for k, v in model.model_dump().items()}
    return {str(k).upper(): v for k, v in dict(model).items()}


def run_extracao_sap():
    """Lê SAP e persiste as rows no Worksheet; não cria cards."""
    cfg = _by_slug("extracao-sap")
    task = instantiate_task(cfg)
    resultado = task.execute(SAP_BASE_DIR)
    print(
        "[extracao-sap] Worksheet atualizado: "
        f"{resultado.get('created', 0)} criadas, "
        f"{resultado.get('updated', 0)} atualizadas."
    )
    return resultado


def run_cruzamento():
    cfg = _by_slug("cruzamento-ativos")
    task = instantiate_task(cfg)
    resultado = task.execute()
    print(
        "[cruzamento-ativos] "
        f"{resultado.get('divergencias', 0)} divergências e "
        f"{resultado.get('cards', 0)} cards criados."
    )
    return resultado


def run_roteamento():
    cfg = _by_slug("roteamento-cruzamento")
    task = instantiate_task(cfg)
    task.execute()
    print("[roteamento-cruzamento] processamento concluído.")


def run_execucao_lw():
    """Executa somente os cards já roteados para a fase automática."""
    cfg = _by_slug("execucao-lw")
    task = instantiate_task(cfg)
    task.execute()
    print("[execucao-lw] consumer encerrado.")


def run_relatorio(resultados: list):
    cfg = _by_slug("relatorio-ativos")
    task = instantiate_task(cfg)
    caminho = task.executar(resultados)
    print(f"[relatorio-ativos] relatório gerado em: {caminho}")


def run_flow(choice: str) -> None:
    """Executa exatamente a etapa escolhida; não encadeia etapas parciais."""
    if choice == "extracao-sap":
        run_extracao_sap()
        return
    if choice == "cruzamento-ativos":
        run_cruzamento()
        return
    if choice == "roteamento-cruzamento":
        run_roteamento()
        return
    if choice == "execucao-lw":
        run_execucao_lw()
        return

    # Somente a opção do fluxo completo encadeia todas as etapas.
    if choice in {"relatorio-ativos", "fluxo-completo"}:
        run_extracao_sap()
        run_cruzamento()
        run_roteamento()
        run_execucao_lw()
        return

    raise ValueError(f"Etapa desconhecida: {choice}")


def main() -> None:
    logging.basicConfig(level=os.getenv("LOGGING_LEVEL", "INFO"))
    while True:
        choice = _menu()
        if choice == "q":
            break
        if choice == "0":
            run_flow("relatorio-ativos")  # fluxo completo
            continue
        if choice.isdigit():
            n = int(choice)
            if 1 <= n <= len(ORDER):
                run_flow(ORDER[n - 1])
                continue
        print("Escolha inválida.")


if __name__ == "__main__":
    main()
