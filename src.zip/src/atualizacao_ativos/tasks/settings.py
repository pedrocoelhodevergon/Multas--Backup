"""
Ergon Task Framework Settings — Atualização de Ativos (SAP → LW).

Configuração global de:
- Logging / Tracing
- Cliente e connector producer do Ergon Platform
- Service LW API

As tasks NUNCA leem variáveis de ambiente diretamente: referenciam
os objetos definidos aqui (exceto constants que centralizam env de domínio).
"""

from __future__ import annotations

import os

from dotenv import load_dotenv

# Carrega explicitamente o arquivo antes de criar os modelos Pydantic do Ergon.
# O framework valida o ENV_FILE, mas algumas versões não fazem o load_dotenv.
_env_file = os.getenv("ENV_FILE", ".env")
load_dotenv(_env_file, override=False)

from ergon import connector, service, telemetry
from ergon.connector.ergon_platform import (
    ErgonPlatformClient,
    ErgonPlatformConnector,
    ErgonPlatformProducerConfig,
)
from ergon.utils import load_env

from atualizacao_ativos.services.lw_api import LwApiConfig, LwApiService
from atualizacao_ativos.services.worksheets.client import WorksheetsClient
from atualizacao_ativos.services.worksheets.ativos.repository import AtivosWorksheetRepository
from atualizacao_ativos.tasks.auditoria_inativacoes.workflow import build_workflow_config

load_env()

# ----------------------------------------
# OTEL Resource
# ----------------------------------------
OTEL_RESOURCE = {
    "service.name": "jsl-ativos-atualizacao",
    "service.version": "0.1.0",
}

# ----------------------------------------
# --- LOGGING ---
# ----------------------------------------
LOGGING = telemetry.logging.LoggingConfig()
LOGGING.level = os.getenv("LOGGING_LEVEL", "INFO")
LOGGING.formatters = [
    telemetry.logging.LogFormatter(
        name="default",
        fmt="[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
    )
]
LOGGING.handlers.append(
    telemetry.logging.ConsoleLogHandler(
        level="DEBUG",
        stream="stdout",
        formatter="default",
    )
)

if os.getenv("ROTATING_FILE_LOGS_ENABLED") == "true":
    LOGGING.handlers.append(
        telemetry.logging.TimedRotatingFileLogHandler(
            level="DEBUG",
            filename=".logs/{task}/task.log",
            when="D",
            interval=1,
            backupCount=os.getenv("ROTATING_FILE_LOGS_BACKUP"),
        )
    )

if os.getenv("OTEL_LOGS_ENABLED") == "true":
    LOGGING.handlers.append(
        telemetry.logging.OTLPLogHandler(
            level="DEBUG",
            resource=OTEL_RESOURCE,
            formatter="default",
            processors=[
                telemetry.logging.LogProcessor(
                    processor=telemetry.logging.BatchLogRecordProcessor,
                    exporters=[
                        telemetry.logging.OTLPLogExporter(
                            endpoint=os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT"),
                            insecure=True,
                        ),
                    ],
                ),
            ],
        )
    )

# ----------------------------------------
# --- TRACING ---
# ----------------------------------------
if os.getenv("OTEL_TRACES_ENABLED") == "true":
    TRACING = telemetry.tracing.TracingConfig()
    TRACING.resource = OTEL_RESOURCE
    TRACING.processors.append(
        telemetry.tracing.SpanProcessor(
            processor=telemetry.tracing.BatchSpanProcessor,
            exporters=[
                telemetry.tracing.OTLPSpanExporter(
                    endpoint=os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT"),
                    insecure=True,
                )
            ],
        )
    )
else:
    TRACING = None

# ----------------------------------------
# --- ERGON PLATFORM ---
# ----------------------------------------
ERGON_PLATFORM_CLIENT = ErgonPlatformClient(
    client_id=os.getenv("ERGON_CLIENT_ID", ""),
    client_secret=os.getenv("ERGON_CLIENT_SECRET", ""),
    base_url=os.getenv("ERGON_BASE_URL", "https://platform.ergondata.ai"),
)


def platform_producer_connector(workflow_id: str, phase_id: str) -> connector.ConnectorConfig:
    """ConnectorConfig do Ergon Platform para criar itens em uma fase."""
    producer_config = ErgonPlatformProducerConfig(
        workflow_id=workflow_id,
        phase_id=phase_id,
    )
    return connector.ConnectorConfig(
        connector=ErgonPlatformConnector,
        kwargs={"client": ERGON_PLATFORM_CLIENT, "producer_config": producer_config},
    )


def platform_consumer_connector(
    workflow_id: str,
    phase_id: str,
    ack_phase_id: str,
    nack_phase_id: str,
    *,
    unassigned: bool = True,
) -> connector.ConnectorConfig:
    """Connector oficial para consumir e rotear o mesmo card."""
    from ergon.connector.ergon_platform import ErgonPlatformConsumerConfig

    consumer_config = ErgonPlatformConsumerConfig(
        workflow_id=workflow_id,
        phase_id=phase_id,
        ack_phase_id=ack_phase_id,
        nack_phase_id=nack_phase_id,
        unassigned=unassigned,
    )
    return connector.ConnectorConfig(
        connector=ErgonPlatformConnector,
        kwargs={"client": ERGON_PLATFORM_CLIENT, "consumer_config": consumer_config},
    )


# ----------------------------------------
# --- LW API SERVICE ---
# ----------------------------------------
# base_url/login/senha do LwApiConfig são usados apenas onde o client não
# sobrescreve por env. Os tokens e base URLs reais (V1 e V2) são lidos pelo
# LwApiClient direto do .env (LW_API_V1/V2_BASE_URL e _TOKEN).
LW_API_CONFIG = LwApiConfig(
    base_url=os.getenv("LW_API_V1_BASE_URL", "https://api.lwtecnologia.com.br/api"),
    login=os.getenv("LW_API_LOGIN", ""),
    senha=os.getenv("LW_API_SENHA", ""),
)

LW_API_SERVICE = service.ServiceConfig(
    service=LwApiService,
    kwargs={"config": LW_API_CONFIG},
)

from atualizacao_ativos.connectors.lw import LwConnector  # noqa: E402

# LwConnector (domínio ativos): embrulha o LwApiService configurado + working_dir.
LW_CONNECTOR = service.ServiceConfig(
    service=LwConnector,
    kwargs={"config": LW_API_CONFIG, "working_dir": os.getenv("ASSETS_DIR", "assets")},
)

WORKSHEETS_CLIENT = service.ServiceConfig(
    service=WorksheetsClient,
    kwargs={
        "base_url": os.getenv("WORKSHEETS_BASE_URL", "https://platform.ergondata.ai/api/v1/worksheets"),
        "token": os.getenv("WORKSHEETS_JWT", ""),
        "worksheet_id": os.getenv("WORKSHEET_ATIVOS_ID", "c495c649-11a1-4647-941b-fa5350ff64fc"),
    },
)

WORKSHEETS_REPOSITORY = service.ServiceConfig(
    service=AtivosWorksheetRepository,
    kwargs={},
)


def build_lw_connector():
    """Instancia o `LwConnector` (para o modo DEBUGGER / uso direto)."""
    return LwConnector(LW_API_CONFIG, working_dir=os.getenv("ASSETS_DIR", "assets"))

# ----------------------------------------
# --- WORKFLOW (IDs do Ergon Data via .env) ---
# ----------------------------------------
WORKFLOW_CONFIG = build_workflow_config()

# ----------------------------------------
# --- TYPE ALIASES ---
# ----------------------------------------
PlatformConnector = ErgonPlatformConnector
LwApiServiceType = LwApiService
