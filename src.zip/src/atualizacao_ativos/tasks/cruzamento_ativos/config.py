"""Configuração do produtor de cards do cruzamento de Ativos."""
from __future__ import annotations

import os

from ergon import task

from atualizacao_ativos.tasks import settings
from atualizacao_ativos.tasks.cruzamento_ativos.task import CruzamentoAtivosTask

TASK_SLUG = "cruzamento-ativos"

PRODUCER_POLICY = task.policies.ProducerPolicy(
    name="producer",
    loop=task.policies.ProducerLoopPolicy(
        concurrency=task.policies.ConcurrencyPolicy(
            value=int(os.getenv("TASK_POLICY_CRUZAMENTO_CONCURRENCY", "1")),
        ),
        batch=task.policies.BatchPolicy(
            size=int(os.getenv("TASK_POLICY_CRUZAMENTO_BATCH", "1")),
        ),
        limit=os.getenv("TASK_POLICY_CRUZAMENTO_LIMIT", None),
    ),
)

TASK_CRUZAMENTO_ATIVOS = task.TaskConfig(
    name=TASK_SLUG,
    task=CruzamentoAtivosTask,
    connectors={
        "output": settings.platform_producer_connector(
            settings.WORKFLOW_CONFIG.workflow_id,
            settings.WORKFLOW_CONFIG.fase_cruzamento,
        )
    },
    services={
        "lw": settings.LW_CONNECTOR,
        "worksheet_repository": settings.WORKSHEETS_REPOSITORY,
    },
    policies=[PRODUCER_POLICY],
    logging=settings.LOGGING,
    tracing=settings.TRACING,
)

task.manager.register(TASK_CRUZAMENTO_ATIVOS)
