"""Task `cruzamento_ativos` (consumidora+produtora): SAP x LW + regras."""

from __future__ import annotations

from atualizacao_ativos.tasks.cruzamento_ativos.config import TASK_CRUZAMENTO_ATIVOS, TASK_SLUG
from atualizacao_ativos.tasks.cruzamento_ativos.task import CruzamentoAtivosTask

__all__ = ["CruzamentoAtivosTask", "TASK_CRUZAMENTO_ATIVOS", "TASK_SLUG"]
