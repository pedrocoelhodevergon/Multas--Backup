"""Cruzamento SAP x LW a partir do Worksheet operacional."""

from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from hashlib import sha256
from typing import Any, List
from uuid import uuid4

from ergon import connector, task
from ergon.connector.ergon_platform import CreateItemInput

from atualizacao_ativos.connectors.lw import LwConnector
from atualizacao_ativos.services.worksheets.ativos.mapper import worksheet_row_to_registro_sap
from atualizacao_ativos.services.worksheets.ativos.repository import AtivosWorksheetRepository
from atualizacao_ativos.tasks import settings
from atualizacao_ativos.tasks.auditoria_inativacoes import rules
from atualizacao_ativos.tasks.auditoria_inativacoes.constants import NAO_CADASTRADO, NAO_LOCALIZADA
from atualizacao_ativos.tasks.auditoria_inativacoes.schemas import (
    AcaoRequerida, RegistroSap, ResultadoAuditoria, VeiculoLw,
)

logger = logging.getLogger(__name__)


def _items_from_response(response: Any) -> list[Any]:
    """Extrai a lista de itens de uma resposta do SDK (dict, modelo ou lista)."""
    if hasattr(response, "model_dump"):
        response = response.model_dump()
    if isinstance(response, list):
        return response
    if isinstance(response, dict):
        for key in ("items", "data", "results"):
            value = response.get(key)
            if isinstance(value, list):
                return value
    return []


def _extract_field_values(item: Any) -> dict[str, Any]:
    """Normaliza os fields de um item do workflow para {NOME: valor}.

    A API pode devolver ``field_values``, ``fields``, ``card_fields`` ou
    ``CARD_FIELDS``, como dict direto, como lista de objetos, ou como dict
    indexado por field_id com objetos internos.
    """
    if hasattr(item, "model_dump"):
        item = item.model_dump()
    if not isinstance(item, dict):
        return {}
    raw = (
        item.get("field_values")
        or item.get("fields")
        or item.get("card_fields")
        or item.get("CARD_FIELDS")
        or item.get("cardFields")
        or {}
    )
    if isinstance(raw, list):
        result: dict[str, Any] = {}
        for entry in raw:
            if isinstance(entry, dict):
                name = (
                    entry.get("field_name")
                    or entry.get("fieldName")
                    or entry.get("name")
                    or entry.get("label")
                )
                if name:
                    result[str(name).upper()] = entry.get("value")
        return result
    if not isinstance(raw, dict):
        return {}
    # Dict indexado por field_id → {field_name: ..., value: ...}
    if all(isinstance(v, dict) for v in raw.values()):
        result = {}
        for _key, entry in raw.items():
            name = (
                entry.get("field_name")
                or entry.get("fieldName")
                or entry.get("name")
                or entry.get("label")
            )
            if name:
                result[str(name).upper()] = entry.get("value")
        return result
    # Dict direto {NOME_DO_FIELD: valor}
    return {str(k).upper(): v for k, v in raw.items()}


class CruzamentoAtivosTask(task.mixins.ProducerTask):
    """Consulta Worksheet, enriquece com LW e cria cards de divergência."""

    lw_service: LwConnector
    worksheet_repository: AtivosWorksheetRepository
    output_connector: connector.Connector
    producer_policy: task.policies.ProducerPolicy

    def __init__(self, connector: LwConnector | None = None, worksheet_repository: AtivosWorksheetRepository | None = None, **kwargs) -> None:
        if connector is not None:
            self.lw_service = connector
        if worksheet_repository is not None:
            self.worksheet_repository = worksheet_repository

    def ler_registros_do_worksheet(self) -> tuple[dict[str, RegistroSap], dict[str, dict]]:
        """Lê todas as páginas e preserva o row_id para o PATCH da LW."""
        repository = (
            getattr(self, "worksheet_repository", None)
            or getattr(self, "worksheet_repository_service", None)
            or AtivosWorksheetRepository()
        )
        registros: dict[str, RegistroSap] = {}
        rows_by_placa: dict[str, dict] = {}
        ignorados = 0
        for row in repository.rows():
            try:
                registro = worksheet_row_to_registro_sap(row)
            except (TypeError, ValueError) as exc:
                ignorados += 1
                logger.warning("Row SAP ignorada no Worksheet: %s", exc)
                continue
            chave = f"{registro.codigo_empresa}|{registro.placa}"
            registros[chave] = registro
            rows_by_placa[chave] = row
        if ignorados:
            logger.warning("Rows SAP ignoradas por dados inválidos: %d", ignorados)
        if not registros:
            raise ValueError("Worksheet de Ativos vazio ou sem rows SAP válidas.")
        logger.info("Rows SAP lidas do Worksheet: %d", len(registros))
        return registros, rows_by_placa

    def _lote_id_from_sap(self, sap_records: dict[str, RegistroSap]) -> str:
        """Gera LOTE_ID determinístico baseado no conteúdo SAP.

        Usa hash SHA-256 das chaves (empresa|placa) ordenadas, garantindo que
        a mesma carga SAP produza o mesmo LOTE_ID entre retries. Override via
        ATIVOS_LOTE_ID para testes.
        """
        override = os.getenv("ATIVOS_LOTE_ID")
        if override:
            return override
        chaves_ordenadas = sorted(sap_records.keys())
        conteudo = "|".join(chaves_ordenadas)
        hash_hex = sha256(conteudo.encode("utf-8")).hexdigest()[:12]
        return f"L{hash_hex}"

    def execute(self) -> dict[str, int]:
        """Executa Worksheet → LW → PATCH → cards de divergência.

        O LOTE_ID é estável por execução (timestamp UTC completo) e pode ser
        sobrescrito via ATIVOS_LOTE_ID para testes/retries. O LOTE_TOTAL
        reflete apenas os cards efetivamente publicados, após o pré-filtro de
        idempotência.
        """
        repository = (
            getattr(self, "worksheet_repository", None)
            or getattr(self, "worksheet_repository_service", None)
            or AtivosWorksheetRepository()
        )
        sap_records, rows_by_placa = self.ler_registros_do_worksheet()
        lw_records = self.baixar_frota_lw()
        self._atualizar_rows_lw(repository, rows_by_placa, lw_records)
        resultados = self.cruzar(sap_records, lw_records)

        lote_id = self._lote_id_from_sap(sap_records)

        # Pré-filtro de idempotência: consultar as chaves já publicadas no
        # workflow para este LOTE_ID, evitando duplicação em retries.
        chaves_existentes = self._chaves_existentes_no_lote(lote_id)
        pares_novos: list[tuple[ResultadoAuditoria, str]] = []
        for resultado in resultados:
            chave = self._chave_idempotencia(resultado, lote_id)
            if chave in chaves_existentes:
                logger.info("Divergência já publicada; chave=%s", chave)
                continue
            pares_novos.append((resultado, chave))

        if not pares_novos:
            logger.info(
                "Lote %s: todas as %d divergências já foram publicadas.",
                lote_id, len(resultados),
            )
            return {
                "rows_sap": len(sap_records),
                "divergencias": len(resultados),
                "cards": 0,
                "lote_id": lote_id,
            }

        lote_total = len(pares_novos)
        cards = self._cards_de_resultado(
            pares_novos, lote_id=lote_id, lote_total=lote_total,
        )
        # Usa o lifecycle do producer (retries, batch, métricas). O limit da
        # política é removido para processar todos os cards do lote em uma
        # execução. Cards já existentes foram removidos pelo pré-filtro de
        # idempotência.
        policy = task.policies.ProducerPolicy(limit=None)
        enviados = self.produce_transactions(cards, policy=policy)
        logger.info(
            "Cruzamento concluído: lote=%s, %d divergências, %d já publicadas, %d cards a publicar, %d despachados.",
            lote_id, len(resultados), len(chaves_existentes), lote_total, enviados,
        )
        return {
            "rows_sap": len(sap_records),
            "divergencias": len(resultados),
            "cards": enviados,
            "lote_id": lote_id,
            "lote_total": lote_total,
        }

    def _atualizar_rows_lw(self, repository, rows_by_placa: dict[str, dict], lw_records: dict[str, VeiculoLw]) -> None:
        sincronizado = datetime.now(timezone.utc).isoformat()
        atualizadas = 0
        for chave, row in rows_by_placa.items():
            placa = chave.split("|", 1)[-1]
            veiculo = lw_records.get(placa)
            values = {
                "id_lw": str(veiculo.id) if veiculo and veiculo.id is not None else None,
                "status_frota_lw": str(veiculo.status_frota or "") if veiculo else "NAO_LOCALIZADO",
                "centro_custo_lw": rules.extrair_cc_recente(veiculo) if veiculo else None,
                "data_ultima_sincronizacao": sincronizado,
            }
            if repository.patch_if_changed(
                row,
                values,
                ignore_fields={"data_ultima_sincronizacao"},
            ):
                atualizadas += 1
        logger.info("Rows LW atualizadas no Worksheet: %d", atualizadas)

    def _cards_de_resultado(
        self,
        resultados_com_chaves: list[tuple[ResultadoAuditoria, str]],
        *,
        lote_id: str,
        lote_total: int,
    ) -> list[connector.Transaction]:
        """Constrói as transactions de criação dos cards de divergência.

        ``lote_total`` é o número efetivo de cards novos do lote (após o
        pré-filtro de idempotência) — todos os cards do lote recebem esse
        valor no field LOTE_TOTAL, permitindo que o relatório consolidado
        saiba quantos cards esperar.
        """
        cards = []
        timestamp = datetime.now(timezone.utc).isoformat()
        for resultado, chave in resultados_com_chaves:
            # Os fields recriados no Workflow são do tipo Text. O modelo
            # retorna ID_VEICULO_LW como int quando existe; normalizamos todos
            # os valores para string antes do CreateItemInput.
            values = {
                str(k).upper(): ("" if v is None else str(v))
                for k, v in resultado.model_dump().items()
            }
            values["STATUS_EXECUCAO"] = "AGUARDANDO_ROTEAMENTO"
            values["STATUS_PROCESSAMENTO"] = "AGUARDANDO_ROTEAMENTO"
            values["DATA_PROCESSAMENTO"] = timestamp
            values["LOTE_ID"] = str(lote_id)
            values["LOTE_TOTAL"] = str(lote_total)
            values["CHAVE_IDEMPOTENCIA"] = chave
            # Estes campos acompanham o card até Finalizado. O consumer
            # substitui o log/status pelo resultado efetivo da chamada LW.
            acao = values.get("ACAO_REQUERIDA", "")
            if "CENTRO DE CUSTO" in acao:
                values["VALOR_ANTERIOR"] = values.get("CENTRO_CUSTO_ATUAL_LW", "")
                values["VALOR_NOVO"] = values.get("CENTRO_CUSTO_SAP", "")
            elif "REATIVAR" in acao:
                values["VALOR_ANTERIOR"] = values.get("STATUS_NA_LW", "")
                values["VALOR_NOVO"] = "ATIVO"
            elif "INATIVA" in acao:
                values["VALOR_ANTERIOR"] = values.get("STATUS_NA_LW", "")
                values["VALOR_NOVO"] = "INATIVO"
            values["MENSAGEM_RETORNO_LW"] = "Aguardando execução na LW."
            values["LOG_EXECUCAO_LW"] = "Aguardando execução na LW."
            values["LOG_EXECUCAO"] = "Aguardando execução na LW."
            values["TRACEBACK_LOG / LOG_EXECUCAO"] = "Aguardando execução na LW."
            # O ID existente na LW é o identificador efetivamente processado.
            # Para as ações de atualização, ele também é o ID retornado.
            values["ID_GERADO_LW"] = values.get("ID_VEICULO_LW", "")
            acao = values.get("ACAO_REQUERIDA", "DIVERGENCIA")
            placa_sap = values.get("PLACA_CRUZADA_SAP", "")
            placa_lw = values.get("PLACA_REGISTRADA_LW", "")
            # Nos casos fantasma, a placa que identifica o veículo está na LW;
            # "NÃO LOCALIZADA" é apenas o marcador do SAP e não pode ser o
            # identificador final do card.
            if acao in {"INATIVAÇÃO", "INATIVACAO"} and placa_sap.upper() in {
                "NÃO LOCALIZADA", "NAO LOCALIZADA"
            }:
                titulo = f"INATIVAÇÃO - NÃO LOCALIZADA - {placa_lw}"
            else:
                titulo = f"{acao} - {placa_sap}"
            card = CreateItemInput(
                title=titulo,
                workflow_id=settings.WORKFLOW_CONFIG.workflow_id,
                phase_id=settings.WORKFLOW_CONFIG.fase_cruzamento,
                field_values=values,
            )
            cards.append(connector.Transaction(id=str(uuid4()), payload=card))
        return cards

    @staticmethod
    def _chave_idempotencia(resultado: ResultadoAuditoria, lote_id: str) -> str:
        dados = resultado.model_dump()
        identidade = "|".join(
            [
                str(lote_id),
                str(dados.get("cnpj_sap") or "").strip(),
                str(dados.get("placa_cruzada_sap") or "").strip().upper(),
                str(dados.get("placa_registrada_lw") or "").strip().upper(),
                str(dados.get("acao_requerida") or "").strip().upper(),
            ]
        )
        return sha256(identidade.encode("utf-8")).hexdigest()

    def _output_backend(self):
        """Retorna o conector de saída instanciado (backend Ergon)."""
        output = getattr(self, "output_connector", None)
        if output is None:
            output = (getattr(self, "connectors", {}) or {}).get("output")
        return output

    def _workflow_scope(self):
        """Retorna o scope do workflow via SDK oficial (client.workflows.workflow)."""
        output = self._output_backend()
        client = getattr(output, "client", None)
        if client is None:
            return None
        try:
            return client.workflows.workflow(settings.WORKFLOW_CONFIG.workflow_id)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Falha ao obter scope do workflow: %s", exc)
            return None

    def _chaves_existentes_no_lote(self, lote_id: str) -> set[str]:
        """Consulta o workflow e retorna as CHAVE_IDEMPOTENCIA já publicadas no lote.

        Usa o SDK oficial via ``client.workflows.workflow(id).items(...)`` com
        paginação. Como ``scope.items()`` retorna itens resumidos (``card_fields``
        contém apenas fields com ``show_on_card=true``), hidrata individualmente
        via ``scope.item(item_id)`` quando LOTE_ID não está presente no resumo.
        Se o client estiver indisponível, retorna vazio (o producer segue sem
        idempotência).
        """
        scope = self._workflow_scope()
        if scope is None:
            logger.warning(
                "Idempotência: scope do workflow indisponível; "
                "prosseguindo sem pré-filtro de chaves existentes.",
            )
            return set()
        chaves: set[str] = set()
        offset = 0
        page_size = 500
        while True:
            try:
                response = scope.items(limit=page_size, offset=offset)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Idempotência: falha ao listar itens do workflow (offset=%d): %s",
                    offset, exc,
                )
                break
            items = _items_from_response(response)
            if not items:
                break
            for item in items:
                fields = _extract_field_values(item)
                # Se LOTE_ID não está no resumo (show_on_card=false), hidratar
                # individualmente para obter todos os fields.
                if not fields.get("LOTE_ID"):
                    try:
                        item_id = item.get("id") if isinstance(item, dict) else getattr(item, "id", None)
                        if item_id:
                            full_item = scope.item(item_id)
                            fields = _extract_field_values(full_item)
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "Idempotência: falha ao hidratar item %s: %s",
                            item_id, exc,
                        )
                        continue
                if str(fields.get("LOTE_ID", "")).strip() == str(lote_id).strip():
                    chave = fields.get("CHAVE_IDEMPOTENCIA")
                    if chave:
                        chaves.add(str(chave).strip())
            if len(items) < page_size:
                break
            offset += page_size
        logger.info(
            "Idempotência: %d chaves existentes encontradas para o lote %s.",
            len(chaves), lote_id,
        )
        return chaves

    def prepare_transaction(self, transaction):
        """Valida a transação antes de entregá-la ao connector de saída."""
        if not isinstance(transaction, connector.Transaction):
            raise TypeError("Cruzamento produziu uma transação inválida.")
        if not transaction.payload:
            raise ValueError(f"Transação {transaction.id} sem payload.")
        return transaction

    def handle_prepare_success(self, transaction, result):
        """Despacha uma transação preparada dentro do lifecycle do producer."""
        output = getattr(self, "output_connector", None)
        if output is None:
            output = getattr(self, "connectors", {}).get("output")
        if output is None:
            raise RuntimeError("Connector de saída do Workflow não foi injetado.")
        response = output.dispatch_transactions([result])
        if response is None or (isinstance(response, (list, tuple)) and not response):
            raise RuntimeError(f"Despacho sem confirmação para a transação {transaction.id}.")
        logger.debug("Card de cruzamento despachado: %s", transaction.id)
        return response

    def handle_prepare_exception(self, transaction, exc):
        logger.exception("Falha no lifecycle de produção do card %s: %s", transaction.id, exc)
        raise exc

    # ------------------------------------------------------------------
    # Lógica de negócio (preservada intacta do original)
    # ------------------------------------------------------------------

    def baixar_frota_lw(self) -> dict[str, VeiculoLw]:
        logger.info("[ETAPA 2] Extraindo dicionário da LW para varredura...")
        return self.lw_service.listar_veiculos_ativos()

    def cruzar(
        self, sap_records: dict[str, RegistroSap], lw_records: dict[str, VeiculoLw]
    ) -> List[ResultadoAuditoria]:
        logger.info("[ETAPA 3] Inspecionando e aplicando regras de negócio...")
        registros = self._aplicar_regras(sap_records, lw_records)
        logger.info("Regras aplicadas: %d divergências encontradas.", len(registros))
        return registros

    def _aplicar_regras(
        self, sap_records: dict[str, RegistroSap], lw_records: dict[str, VeiculoLw]
    ) -> List[ResultadoAuditoria]:
        if not sap_records:
            raise ValueError(
                "Snapshot SAP vazio: não é permitido classificar veículos da LW como ausentes."
            )
        resultados: List[ResultadoAuditoria] = []
        placas_lw_visitadas = set()

        for _, dados_sap in sap_records.items():
            placa_sap = dados_sap.placa
            v_lw = lw_records.get(placa_sap)
            placa_match_lw = placa_sap

            if not v_lw:
                placa_alt = rules.gerar_variacao_mercosul_antiga(placa_sap)
                if placa_alt:
                    v_lw = lw_records.get(placa_alt)
                    if v_lw:
                        placa_match_lw = placa_alt

            if v_lw:
                placas_lw_visitadas.add(placa_match_lw)

            cc_lw = rules.extrair_cc_recente(v_lw) if v_lw else NAO_CADASTRADO
            id_veiculo_lw = v_lw.id if v_lw else None
            status_lw_str = str(v_lw.status_frota).strip().upper() if v_lw else NAO_CADASTRADO

            acao, detalhes = rules.decidir_acao(dados_sap, v_lw, cc_lw)
            if acao == AcaoRequerida.NENHUMA:
                continue

            resultados.append(
                rules.montar_resultado(
                    id_veiculo_lw=id_veiculo_lw,
                    placa_registrada_lw=placa_match_lw if v_lw else NAO_LOCALIZADA,
                    placa_cruzada_sap=placa_sap,
                    acao=acao,
                    detalhes=detalhes,
                    dados_sap=dados_sap,
                    cc_lw=cc_lw,
                    status_lw_str=status_lw_str,
                )
            )

        for placa_lw, v_lw in lw_records.items():
            if placa_lw in placas_lw_visitadas:
                continue
            if str(v_lw.status_frota).strip().upper() != "ATIVO":
                continue
            cc_lw = rules.extrair_cc_recente(v_lw)
            resultados.append(
                rules.montar_resultado(
                    id_veiculo_lw=v_lw.id,
                    placa_registrada_lw=placa_lw,
                    placa_cruzada_sap=NAO_LOCALIZADA,
                    acao=AcaoRequerida.INATIVACAO,
                    detalhes="FANTASMA: Veículo ATIVO na LW, ausente no SAP.",
                    dados_sap=None,
                    cc_lw=cc_lw,
                    status_lw_str=str(v_lw.status_frota).strip().upper(),
                )
            )

        return resultados
