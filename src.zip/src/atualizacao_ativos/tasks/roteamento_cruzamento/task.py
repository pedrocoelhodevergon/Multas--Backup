"""Roteia cards criados pelo cruzamento para EA ou Validação Humana."""

from __future__ import annotations

import logging
from ergon import connector, task

from atualizacao_ativos.tasks import settings
from atualizacao_ativos.services.ergon_payload import payload_from_transaction

logger = logging.getLogger(__name__)

_AUTOMATICAS = {
    "INATIVAÇÃO",
    "INATIVACAO",
    "REATIVAR",
    "ALTERAÇÃO DE CENTRO DE CUSTO",
    "ALTERACAO DE CENTRO DE CUSTO",
}


class RoteamentoCruzamentoTask(task.mixins.ConsumerTask):
    """Move cards do Resultado para a fase operacional correta."""

    workflow_connector: connector.Connector
    consumer_policy: task.policies.ConsumerPolicy

    def execute(self) -> None:
        self.consume_transactions(self.consumer_policy)

    def process_transaction(self, transaction: connector.Transaction) -> dict:
        payload = payload_from_transaction(transaction, self.workflow_connector)
        fields = payload.get("field_values") or payload.get("fields") or payload
        fields = {str(k).upper(): v for k, v in dict(fields or {}).items()}
        action = str(fields.get("ACAO_REQUERIDA", "")).strip().upper()

        if action in _AUTOMATICAS:
            target = settings.WORKFLOW_CONFIG.fase_ea_lw
        else:
            target = settings.WORKFLOW_CONFIG.fase_validacao_humana

        logger.info(
            "Roteando card %s | acao=%s | destino=%s",
            transaction.id,
            action,
            target,
        )
        return {"phase_id": target, "acao": action}

    def handle_process_success(self, transaction: connector.Transaction, result: dict) -> None:
        self.workflow_connector.ack_transaction(
            transaction,
            phase_id=result["phase_id"],
        )

    def handle_process_exception(self, transaction: connector.Transaction, exception: Exception) -> None:
        logger.exception("Falha ao rotear card %s", transaction.id)
        self.workflow_connector.nack_transaction(transaction, requeue=False)
