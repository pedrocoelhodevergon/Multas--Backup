"""Consumer que roteia cards do resultado do cruzamento."""
from __future__ import annotations

from ergon import task

from atualizacao_ativos.tasks import settings
from atualizacao_ativos.tasks.policies import consumer_policy
from atualizacao_ativos.tasks.roteamento_cruzamento.task import RoteamentoCruzamentoTask

TASK_SLUG = "roteamento-cruzamento"

TASK_ROTEAMENTO_CRUZAMENTO = task.TaskConfig(
    name=TASK_SLUG,
    task=RoteamentoCruzamentoTask,
    connectors={"workflow": settings.platform_consumer_connector(
        settings.WORKFLOW_CONFIG.workflow_id,
        settings.WORKFLOW_CONFIG.fase_cruzamento,
        settings.WORKFLOW_CONFIG.fase_cruzamento,
        settings.WORKFLOW_CONFIG.fase_erros,
    )},
    policies=[consumer_policy("roteamento-cruzamento", "TASK_POLICY_ROTEAMENTO")],
    logging=settings.LOGGING,
    tracing=settings.TRACING,
)

task.manager.register(TASK_ROTEAMENTO_CRUZAMENTO)
