"""Roteamento dos cards do resultado do cruzamento."""
