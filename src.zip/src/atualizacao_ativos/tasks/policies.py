"""Policies padronizadas do fluxo de ativos."""
from __future__ import annotations

import os
from ergon import task


def consumer_policy(name: str, env_prefix: str, connector_name: str = "workflow") -> task.policies.ConsumerPolicy:
    """Política conservadora: lote padrão de um card.

    A ampliação do lote precisa ser explícita via ``*_BATCH`` após o teste
    controlado; isso evita consumir milhares de itens por engano.
    """
    return task.policies.ConsumerPolicy(
        name="consumer",
        fetch=task.policies.FetchPolicy(
            connector_name=connector_name,
            batch=task.policies.BatchPolicy(
                # Segurança operacional: o primeiro lote deve ser explicitamente
                # ampliado pelo operador após validar um card controlado.
                size=int(os.getenv(f"{env_prefix}_BATCH", "1")),
            ),
        ),
        loop=task.policies.ConsumerLoopPolicy(
            concurrency=task.policies.ConcurrencyPolicy(
                value=int(os.getenv(f"{env_prefix}_CONCURRENCY", "1")),
            ),
        ),
        process=task.policies.ProcessPolicy(),
        success=task.policies.SuccessPolicy(),
        exception=task.policies.ExceptionPolicy(),
    )


def producer_policy(name: str, env_prefix: str) -> task.policies.ProducerPolicy:
    return task.policies.ProducerPolicy(name=name)
