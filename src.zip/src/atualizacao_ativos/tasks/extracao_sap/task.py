"""Carga da planilha SAP no Worksheet operacional de Ativos."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from ergon import connector, task

from atualizacao_ativos.connectors.lw import LwConnector
from atualizacao_ativos.services.worksheets.ativos.mapper import registro_sap_to_row
from atualizacao_ativos.services.worksheets.ativos.repository import AtivosWorksheetRepository

logger = logging.getLogger(__name__)


class ExtracaoSapTask(task.mixins.ProducerTask):
    """Lê SAP e persiste as rows no Worksheet via lifecycle do ProducerTask."""

    lw_service: LwConnector
    worksheet_repository: AtivosWorksheetRepository
    producer_policy: task.policies.ProducerPolicy

    def __init__(
        self,
        connector: LwConnector | None = None,
        worksheet_repository: AtivosWorksheetRepository | None = None,
        **kwargs,
    ) -> None:
        if connector is not None:
            self.lw_service = connector
        if worksheet_repository is not None:
            self.worksheet_repository = worksheet_repository
        self._upsert_stats = {"created": 0, "updated": 0, "failed": 0}
        self._existing_index: dict[str, dict[str, Any]] | None = None

    def _repository(self) -> AtivosWorksheetRepository:
        return (
            getattr(self, "worksheet_repository", None)
            or getattr(self, "worksheet_repository_service", None)
            or AtivosWorksheetRepository()
        )

    def execute(self, sap_base_dir: str | None = None) -> dict[str, int]:
        base_dir = sap_base_dir or os.getenv("SAP_BASE_DIR")
        if not base_dir:
            base_dir = str(Path(__file__).resolve().parents[4] / "assets" / "planilhas_sap")

        sap_records = self.executar(base_dir)
        if not sap_records:
            raise RuntimeError(f"Nenhum registro SAP encontrado em {base_dir}.")

        # Carrega o índice de rows existentes UMA VEZ para evitar O(N²).
        repository = self._repository()
        self._existing_index = repository.load_existing_index()
        logger.info(
            "Índice SAP carregado: %d rows existentes no Worksheet.",
            len(self._existing_index),
        )

        origem = os.path.abspath(base_dir)
        transactions = []
        for registro in sap_records.values():
            row = registro_sap_to_row(registro, origem=origem)
            chave = str(row.get("chave_sap") or "")
            if not chave:
                raise ValueError("Registro SAP sem chave_sap não pode ser produzido.")
            transactions.append(
                connector.Transaction(id=chave, payload=row)
            )

        self._upsert_stats = {"created": 0, "updated": 0, "failed": 0}
        produced = self.produce_transactions(
            transactions,
            policy=self.producer_policy,
        )
        logger.info(
            "[WORKSHEET ATIVOS] SAP persistido via ProducerTask: %d transações, %d criadas, %d atualizadas, %d falharam.",
            produced,
            self._upsert_stats["created"],
            self._upsert_stats["updated"],
            self._upsert_stats["failed"],
        )
        return {**self._upsert_stats, "transactions": produced}

    def prepare_transaction(self, transaction: connector.Transaction) -> dict:
        payload = transaction.payload
        if not isinstance(payload, dict):
            raise TypeError(f"Payload SAP inválido para {transaction.id}.")
        if not payload.get("chave_sap"):
            raise ValueError(f"Payload SAP sem chave_sap para {transaction.id}.")
        return payload

    def handle_prepare_success(self, transaction, result):
        resultado = self._repository().upsert_sap_rows(
            [result], existing_index=self._existing_index
        )
        self._upsert_stats["created"] += resultado.get("created", 0)
        self._upsert_stats["updated"] += resultado.get("updated", 0)
        return resultado

    def handle_prepare_exception(self, transaction, exc):
        self._upsert_stats["failed"] += 1
        logger.exception("Falha ao persistir row SAP %s: %s", transaction.id, exc)
        raise exc

    def executar(self, sap_base_dir: str) -> dict:
        logger.info("[ETAPA 1] Lendo planilhas SAP em %s ...", sap_base_dir)
        sap_records = self.lw_service.ler_planilhas_sap(sap_base_dir)
        if not sap_records:
            logger.error("Nenhuma base SAP válida foi processada. Abortando.")
        return sap_records
