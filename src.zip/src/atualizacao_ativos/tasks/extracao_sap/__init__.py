"""Task `extracao_sap` (produtora): leitura/consolidação das planilhas SAP."""

from __future__ import annotations

from atualizacao_ativos.tasks.extracao_sap.config import TASK_EXTRACAO_SAP, TASK_SLUG
from atualizacao_ativos.tasks.extracao_sap.task import ExtracaoSapTask

__all__ = ["ExtracaoSapTask", "TASK_EXTRACAO_SAP", "TASK_SLUG"]
