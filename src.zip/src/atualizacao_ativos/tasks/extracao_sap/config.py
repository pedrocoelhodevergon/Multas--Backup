"""Configuração da task `extracao_sap`: política + DI + registro.

> Lê as planilhas SAP e persiste as rows no Worksheet operacional.
> Não cria cards e não existe fase intermediária de SAP.
"""

from __future__ import annotations

import os

from ergon import task

from atualizacao_ativos.tasks import settings
from atualizacao_ativos.tasks.extracao_sap.task import ExtracaoSapTask

TASK_SLUG = "extracao-sap"

PRODUCER_POLICY = task.policies.ProducerPolicy(
    name="producer",
    loop=task.policies.ProducerLoopPolicy(
        concurrency=task.policies.ConcurrencyPolicy(value=int(os.getenv("TASK_POLICY_EXTRACAO_SAP_CONCURRENCY", 1))),
        batch=task.policies.BatchPolicy(size=int(os.getenv("TASK_POLICY_EXTRACAO_SAP_BATCH", 100))),
        limit=os.getenv("TASK_POLICY_EXTRACAO_SAP_LIMIT", None),
    ),
)

TASK_EXTRACAO_SAP = task.TaskConfig(
    name=TASK_SLUG,
    task=ExtracaoSapTask,
    services={
        "lw": settings.LW_CONNECTOR,
        "worksheet_repository": settings.WORKSHEETS_REPOSITORY,
    },
    policies=[PRODUCER_POLICY],
    logging=settings.LOGGING,
    tracing=settings.TRACING,
)

task.manager.register(TASK_EXTRACAO_SAP)
