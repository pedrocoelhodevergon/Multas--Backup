"""Helpers locais da task `auditoria_inativacoes` e de infra (assets)."""

import os
from typing import Optional

from .constants import ELIMINAR_PLACA, NAO_LOCALIZADA


def resolver_placa_operacional(item_auditoria: dict) -> Optional[str]:
    """Resolve qual placa usar como chave da operação na LW, seguindo os
    fallbacks originais: PLACA_REGISTRADA_LW → PLACA_CRUZADA_SAP → PLACA."""
    placa = item_auditoria.get("PLACA_REGISTRADA_LW")
    if not placa or str(placa).strip() in ELIMINAR_PLACA:
        placa = item_auditoria.get("PLACA_CRUZADA_SAP") or item_auditoria.get("PLACA")
    return str(placa).strip() if placa else None


def resolver_assets_dir() -> str:
    """Caminho da pasta compartilhada `src/assets` (infra) deste projeto.

    Env `ASSETS_DIR` tem prioridade. Por padrão sobe até `src/` (pasta-mãe do
    pacote) e aponta para `src/assets`.
    """
    override = os.getenv("ASSETS_DIR", "").strip()
    if override:
        return os.path.abspath(override)

    # .../atualizacao_ativos/tasks/auditoria_inativacoes/helper.py -> subir até src
    src_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    return os.path.join(src_dir, "assets")


def resolver_pasta_planilhas() -> str:
    """Pasta padrão das planilhas SAP de entrada (em `assets/planilhas_sap`)."""
    return os.path.join(resolver_assets_dir(), "planilhas_sap")
