"""Task `auditoria_inativacoes` — coordenador do Fluxo Invertido (SAP → LW).

É a ORCHESTRAÇÃO FINA: não faz I/O (planilha, API, arquivo) nem regras — isso
ficou nas tasks de etapa:

    [ETAPA 1] `tasks/extracao_sap`        → lê planilhas SAP (mega dicionário)
    [ETAPA 2/3] `tasks/cruzamento_ativos` → baixa frota LW + aplica regras
    [ETAPA 4] `tasks/relatorio_ativos`    → grava relatório xlsx
    (escrita direta na LW) `tasks/execucao_lw`

Aqui o coordenador apenas injeta o conector nas etapas e as compõe em ordem.

> ⚠️ Nota de integração com o Ergon:
> A assinatura exata da classe base `Task` (métodos `process/success/exception/
> execute`) depende da versão do framework instalada. A lógica cai direto no
> `execute()`. Confirme contra o `tasks/example_task/task.py` do template.
"""

import logging
from typing import List, Optional

from atualizacao_ativos.connectors.lw import LwConnector
from atualizacao_ativos.tasks.auditoria_inativacoes.schemas import ResultadoAuditoria
from atualizacao_ativos.tasks.cruzamento_ativos.task import CruzamentoAtivosTask
from atualizacao_ativos.tasks.execucao_lw.task import ExecucaoLwTask
from atualizacao_ativos.tasks.extracao_sap.task import ExtracaoSapTask
from atualizacao_ativos.tasks.relatorio_ativos.task import RelatorioAtivosTask

logger = logging.getLogger(__name__)


class AuditoriaInativacoes:
    """Orquestra a auditoria invertida SAP ➡️ LW compondo as 4 tasks de etapa.

    Fluxo:
      [ETAPA 1] Lê planilhas SAP -> mega dicionário de placas únicas.
      [ETAPA 2] Baixa a frota ativa da LW.
      [ETAPA 3] Cruza e aplica as regras de negócio -> lista de ResultadoAuditoria.
      [ETAPA 4] Grava o relatório xlsx.
    """

    def __init__(self, connector: LwConnector):
        self.connector = connector
        # Tasks de etapa (DI por conector).
        self.extracao_sap = ExtracaoSapTask(connector)
        self.cruzamento = CruzamentoAtivosTask(connector)
        self.execucao_lw = ExecucaoLwTask(connector)
        self.relatorio = RelatorioAtivosTask(connector)

    # ------------------------------------------------------------------
    # Orquestração
    # ------------------------------------------------------------------

    def execute(self, sap_base_dir: str) -> tuple[Optional[str], List[ResultadoAuditoria]]:
        """Roda a auditoria completa e devolve (caminho_do_relatorio, resultados)."""
        logger.info("--- Iniciando Processo MC01/MC02: AUDITORIA INVERTIDA (SAP ➡️ LW) ---")

        # [ETAPA 1] planilhas SAP -> mega dicionário
        sap_records = self.extracao_sap.executar(sap_base_dir)
        if not sap_records:
            logger.error("Nenhuma base SAP válida foi processada. Abortando.")
            return "", []

        # [ETAPA 2] frota ativa da LW + [ETAPA 3] regras de negócio
        lw_records = self.cruzamento.baixar_frota_lw()
        resultados = self.cruzamento.cruzar(sap_records, lw_records)

        # [ETAPA 4] relatório
        arquivo_final = self.relatorio.executar(resultados)
        return arquivo_final, resultados

    # ------------------------------------------------------------------
    # Aplicação direta na LW (acionada pelo runner/API da operação)
    # ------------------------------------------------------------------

    def executar_atualizacao_direta_lw(self, item_auditoria: dict) -> tuple[bool, str]:
        """Delega a aplicação de ações diretas na LW V2 à task de etapa."""
        return self.execucao_lw.executar(item_auditoria)
