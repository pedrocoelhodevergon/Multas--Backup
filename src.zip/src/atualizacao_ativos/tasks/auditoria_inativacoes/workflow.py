"""Config de ambiente do Ergon Data para a task `auditoria_inativacoes`.

Centraliza os IDs de workflow e de fase que vêm do `.env` (no formato
`WORKFLOW_*`/`PHASE_*`). A task e o `ErgonPlatformConnector` referenciam estes
objetos — NUNCA chamam `os.getenv` com defaults ad hoc espalhados.

> Estes IDs NÃO são segredos, mas são ambiente-específicos, então vivem em
> `settings.py`/env e são expostos aqui em vez de hardcoded em constants.py.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class WorkflowAtivosConfig:
    """IDs de workflow e fases do fluxo MC01 (Gestão de Ativos)."""

    workflow_id: str
    fase_cruzamento: str
    fase_validacao_humana: str
    fase_ea_lw: str
    fase_erros: str
    fase_finalizado: str
    fase_historico: str
    fase_relatorio: str
    chave_idempotencia_field_id: str

    # Alias com nomenclatura do fluxo de apresentação (para compatibilidade).
    @property
    def fase_concluido(self) -> str:
        return self.fase_finalizado


def build_workflow_config() -> WorkflowAtivosConfig:
    """Monta o config a partir do ambiente (com default por env ausente).

    Valida que todas as fases obrigatórias estão configuradas antes de
    retornar. Falha rápida no startup evita erros em tempo de execução.
    """
    config = WorkflowAtivosConfig(
        workflow_id=os.getenv("WORKFLOW_ATIVOS_ID", ""),
        fase_cruzamento=os.getenv("PHASE_CRUZAMENTO_ID", ""),
        fase_validacao_humana=os.getenv("PHASE_VALIDACAO_HUMANA_ID", ""),
        fase_ea_lw=os.getenv("PHASE_EA_LW_ID", ""),
        fase_erros=os.getenv("PHASE_ERROS_ID", ""),
        fase_finalizado=os.getenv("PHASE_FINALIZADO_ID", ""),
        fase_historico=os.getenv("PHASE_HISTORICO_ID", ""),
        fase_relatorio=os.getenv("PHASE_RELATORIO_ID", ""),
        chave_idempotencia_field_id=os.getenv("CHAVE_IDEMPOTENCIA_FIELD_ID", ""),
    )

    # Validação de startup: todas as fases obrigatórias devem estar preenchidas.
    campos_obrigatorios = [
        ("workflow_id", config.workflow_id),
        ("fase_cruzamento", config.fase_cruzamento),
        ("fase_validacao_humana", config.fase_validacao_humana),
        ("fase_ea_lw", config.fase_ea_lw),
        ("fase_erros", config.fase_erros),
        ("fase_finalizado", config.fase_finalizado),
        ("fase_relatorio", config.fase_relatorio),
        ("chave_idempotencia_field_id", config.chave_idempotencia_field_id),
    ]
    faltantes = [nome for nome, valor in campos_obrigatorios if not valor]
    if faltantes:
        raise RuntimeError(
            f"Configuração do workflow incompleta. Campos obrigatórios sem valor: {faltantes}. "
            f"Verifique as variáveis de ambiente no .env."
        )

    return config
