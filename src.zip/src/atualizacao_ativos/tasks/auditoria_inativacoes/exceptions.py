"""Exceções específicas da task `auditoria_inativacoes`.

> Se o Ergon expõe uma classe base (`TransactionException` ou similar),
> subclasse-a aqui — ex.: `class AuditoriaError(TransactionException)`. Ajuste
> conforme o framework instalado.
"""


class AuditoriaError(Exception):
    """Erro genérico do fluxo de auditoria."""


class DiretorioSapInexistente(AuditoriaError):
    """O diretório de planilhas SAP não existe ou está vazio."""


class NenhumaPlanilhaValida(AuditoriaError):
    """Nenhuma planilha SAP foi lida com sucesso."""
