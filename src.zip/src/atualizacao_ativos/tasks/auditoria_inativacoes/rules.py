"""Regras de negócio PURAS da auditoria invertida (SAP → LW).

Aqui NÃO há I/O: nenhuma leitura de arquivo, nenhuma chamada de rede,
nenhum openpyxl. Tudo recebe dados prontos e devolve dados prontos.

Isso permite testar a regra com um simples teste unitário, sem depender
de planilha, API da LW ou pastas do sistema.
"""

from typing import Optional

from .constants import SEM_CC_ATRELADO, SEM_CC_NO_SAP
from .schemas import (
    AcaoRequerida,
    RegistroSap,
    ResultadoAuditoria,
    VeiculoLw,
)

# --------------------------------------------------------------------------
# Helpers de normalização (movidos intactos do código original)
# --------------------------------------------------------------------------


def normalizar_placa(placa: str) -> str:
    if not placa:
        return ""
    return "".join(c for c in placa if c.isalnum()).strip().upper()


def gerar_variacao_mercosul_antiga(placa: str) -> Optional[str]:
    """Gera a variação da placa antiga (formato Mercosul ↔ padrão antigo)."""
    if not placa or len(placa) != 7:
        return None

    char4 = placa[4]
    mapping_num_to_let = {
        "0": "A", "1": "B", "2": "C", "3": "D", "4": "E",
        "5": "F", "6": "G", "7": "H", "8": "I", "9": "J",
    }
    mapping_let_to_num = {v: k for k, v in mapping_num_to_let.items()}

    if char4.isdigit():
        alt = mapping_num_to_let.get(char4)
        return placa[:4] + alt + placa[5:] if alt else None
    if char4.isalpha():
        alt = mapping_let_to_num.get(char4.upper())
        return placa[:4] + alt + placa[5:] if alt else None
    return None


def extrair_cc_recente(v_lw: VeiculoLw) -> str:
    """Resolve o Centro de Custo mais recente do veículo na LW."""
    cc_lw = SEM_CC_ATRELADO
    grupos_v2 = v_lw.grupos or []
    historicos = v_lw.historicos or []

    id_grupo_recente = None
    if historicos:
        hist_validos = [
            h for h in historicos
            if h.get("dataInicio") and h.get("idGrupo") and h.get("idGrupo") > 0
        ]
        if hist_validos:
            hist_ordenados = sorted(
                hist_validos,
                key=lambda x: (x.get("dataInicio"), x.get("id", 0)),
                reverse=True,
            )
            id_grupo_recente = hist_ordenados[0].get("idGrupo")

    if not id_grupo_recente:
        id_grupo_recente = v_lw.id_grupo

    if grupos_v2 and id_grupo_recente:
        for grupo in grupos_v2:
            if grupo.get("id") == id_grupo_recente:
                cc_encontrado = str(grupo.get("centroCusto", "")).strip()
                if cc_encontrado:
                    cc_lw = cc_encontrado
                break
    return cc_lw


# --------------------------------------------------------------------------
# Regra de decisão (que aponta a ACAO_REQUERIDA)
# --------------------------------------------------------------------------


def decidir_acao(
    dados_sap: RegistroSap,
    v_lw: Optional[VeiculoLw],
    cc_lw: str,
) -> tuple[AcaoRequerida, str]:
    """Decide a ação requerida para um veículo, dada a situação SAP × LW.

    Retorna `(acao, detalhes)`. Regras idênticas às do código original.
    """
    codigo_empresa = dados_sap.codigo_empresa
    nome_empresa = dados_sap.empresa
    is_active_sap = dados_sap.is_active
    cc_sap = dados_sap.cc
    status_sap_bruto = dados_sap.status_bruto

    in_lw = bool(v_lw)
    status_lw_str = str(v_lw.status_frota).strip().upper() if in_lw else "NÃO CADASTRADO"

    # Regra especial: MOVIDA (6800) → sempre inativar.
    if codigo_empresa == "6800":
        if in_lw and status_lw_str == "ATIVO":
            return AcaoRequerida.INATIVACAO, (
                "Veículo pertence à MOVIDA (6800) e deve ser inativado na LW."
            )
        return AcaoRequerida.NENHUMA, ""

    # Veículo ausente na LW.
    if not in_lw:
        if is_active_sap:
            if not dados_sap.renavam or not dados_sap.chassi:
                return AcaoRequerida.DADOS_INCOMPLETOS, (
                    "Veículo ATIVO no SAP e ausente na LW, porém faltam Renavam/Chassi."
                )
            return AcaoRequerida.CADASTRAR, (
                "Veículo ATIVO no SAP, não encontrado na LW. Pronto para cadastro."
            )
        return AcaoRequerida.NENHUMA, ""

    # Veículo presente na LW.
    if status_lw_str == "INATIVO" and is_active_sap:
        return AcaoRequerida.REATIVAR, (
            "Placa ATIVA no SAP, mas INATIVA na LW."
        )

    if status_lw_str == "ATIVO" and not is_active_sap:
        return AcaoRequerida.INATIVACAO, (
            f"Veículo ATIVO na LW, mas INATIVO no SAP ({status_sap_bruto})."
        )

    if status_lw_str == "ATIVO" and is_active_sap:
        if codigo_empresa not in {"1000", "1200", "3150", "3200", "7000", "9100"}:
            return AcaoRequerida.ALTERACAO_EMPRESA, (
                f"CNPJ DIVERGENTE: Veículo ativo como {nome_empresa}."
            )
        if cc_sap != SEM_CC_NO_SAP and cc_sap != cc_lw:
            return AcaoRequerida.ALTERACAO_CENTRO_CUSTO, (
                f"SAP: {cc_sap} | LW: {cc_lw}"
            )

    return AcaoRequerida.NENHUMA, ""


# --------------------------------------------------------------------------
# Consolidação (monta os itens de resultado da auditoria)
# --------------------------------------------------------------------------


def montar_resultado(
    id_veiculo_lw: Optional[int],
    placa_registrada_lw: str,
    placa_cruzada_sap: str,
    acao: AcaoRequerida,
    detalhes: str,
    dados_sap: Optional[RegistroSap],
    cc_lw: str,
    status_lw_str: str,
) -> ResultadoAuditoria:
    """Constrói um `ResultadoAuditoria` a partir dos dados já calculados."""
    if dados_sap is None:
        return ResultadoAuditoria(
            id_veiculo_lw=id_veiculo_lw,
            placa_registrada_lw=placa_registrada_lw,
            placa_cruzada_sap=placa_cruzada_sap,
            acao_requerida=acao.value,
            motivo_divergencia=detalhes,
            empresa_no_sap="NÃO CADASTRADO",
            centro_custo_sap="NÃO CADASTRADO",
            centro_custo_atual_lw=cc_lw,
            status_no_sap="NÃO CADASTRADO",
            status_na_lw=status_lw_str,
            renavam_sap="",
            chassi_sap="",
            cnpj_sap="",
        )

    return ResultadoAuditoria(
        id_veiculo_lw=id_veiculo_lw,
        placa_registrada_lw=placa_registrada_lw,
        placa_cruzada_sap=placa_cruzada_sap,
        acao_requerida=acao.value,
        motivo_divergencia=detalhes,
        empresa_no_sap=dados_sap.empresa,
        centro_custo_sap=dados_sap.cc,
        centro_custo_atual_lw=cc_lw,
        status_no_sap=dados_sap.status_bruto,
        status_na_lw=status_lw_str,
        renavam_sap=dados_sap.renavam,
        chassi_sap=dados_sap.chassi,
        cnpj_sap=dados_sap.cnpj,
    )
