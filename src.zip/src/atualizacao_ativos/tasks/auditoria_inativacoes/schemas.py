"""Modelos de domínio da task `auditoria_inativacoes` (Pydantic)."""

from enum import Enum
from typing import Optional

from pydantic import BaseModel


class AcaoRequerida(str, Enum):
    """Ações que a auditoria pode apontar para um veículo."""
    NENHUMA = "NENHUMA"
    INATIVACAO = "INATIVAÇÃO"
    REATIVAR = "REATIVAR"
    CADASTRAR = "CADASTRAR"
    DADOS_INCOMPLETOS = "DADOS INCOMPLETOS"
    ALTERACAO_EMPRESA = "ALTERAÇÃO DE EMPRESA/CNPJ"
    ALTERACAO_CENTRO_CUSTO = "ALTERAÇÃO DE CENTRO DE CUSTO"


class RegistroSap(BaseModel):
    """Um veículo como lido/consolidado das planilhas SAP."""
    placa: str
    is_active: bool
    status_bruto: str
    cc: str
    codigo_empresa: str
    empresa: str
    renavam: str
    chassi: str
    cnpj: str = ""


class VeiculoLw(BaseModel):
    """Visão mínima de um veículo vindo da LW V2."""
    id: Optional[int] = None
    placa: str
    status_frota: str
    id_grupo: Optional[int] = None
    grupos: list = []
    historicos: list = []


class ResultadoAuditoria(BaseModel):
    """Um item de divergência apontado pela auditoria."""
    id_veiculo_lw: Optional[int] = None
    placa_registrada_lw: str
    placa_cruzada_sap: str
    acao_requerida: str
    motivo_divergencia: str
    empresa_no_sap: str
    centro_custo_sap: str
    centro_custo_atual_lw: str
    status_no_sap: str
    status_na_lw: str
    renavam_sap: str
    chassi_sap: str
    cnpj_sap: str = ""
