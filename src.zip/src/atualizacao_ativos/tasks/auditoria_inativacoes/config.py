"""Config do coordenador de DEBUG `auditoria_inativacoes`.

> NÃO é uma task registrada no Ergon (Modo B: as 4 etapas são tasks
> independentes). Este coordenador compõe as 4 etapas em ordem para o modo
> DEBUGGER local (rodar o processo inteiro de uma vez e depurar etapa a etapa).

> ⚠️ Circular import: manter imports lazy (nunca no topo) para não inicializar o
> pacote `tasks` no meio da carga de um connector.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

TASK_SLUG = "auditoria-inativacoes"


def build_debug_coordinator(connector=None):
    """Monta o coordenador de debug pronto para rodar o fluxo completo."""
    from atualizacao_ativos.tasks.auditoria_inativacoes.task import AuditoriaInativacoes

    if connector is None:
        from atualizacao_ativos.tasks import settings

        connector = settings.build_lw_connector()
    return AuditoriaInativacoes(connector)
