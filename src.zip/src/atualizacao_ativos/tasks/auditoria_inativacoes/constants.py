"""Constantes e políticas default da task `auditoria_inativacoes`.

Fluxo Invertido (SAP → LW): varre a pasta de planilhas SAP, consolida os dados,
mapeia o de-para das empresas do grupo JSL e cruza com a frota da LW.

> ⚠️ Regra de arquitetura: aqui ficam apenas constantes de DOMÍNIO (mapas,
> sentinelas, textos). NADA de segredos/tokens/credenciais e NADA de IDs de
> workflow/fase. Esses são config de ambiente e vivem no `.env`, lidos por
> `tasks/settings.py` (via `load_env`) e por `workflow.py`.
"""

# Mapa de código de empresa SAP → razão social.
MAPA_EMPRESAS = {
    "1000": "JSL",
    "1200": "SINAL",
    "3150": "FAZENDA SÃO JUDAS",
    "3200": "INTRALOG",
    "6800": "MOVIDA",
    "7000": "AGROLOG",
    "9100": "TRANSMORENO",
}

# Empresas cuja gestão é feita (não gera ALTERAÇÃO DE EMPRESA/CNPJ).
CODIGOS_EMPRESAS_GESTAO = {"1000", "1200", "3150", "3200", "7000", "9100"}

# Status/valores sentinela usados ao longo do fluxo.
SEM_CC_NO_SAP = "SEM_CC_NO_SAP"
SEM_CC_ATRELADO = "SEM_CC_ATRELADO"
NAO_CADASTRADO = "NÃO CADASTRADO"
NAO_LOCALIZADA = "NÃO LOCALIZADA"
ELIMINAR_PLACA = {"NÃO LOCALIZADA", "SEM_PLACA", "", None}

# Ações que o robô executa AUTOMATICAMENTE na LW (escrita direta na V2).
ACOES_AUTOMATICAS = {"INATIVAÇÃO", "REATIVAR", "ALTERAÇÃO DE CENTRO DE CUSTO"}

# Cabeçalhos que a planilha SAP não deve expor ao usuário final (ID interno).
CABECALHOS_OCULTOS = {"ID_VEICULO_LW"}

# Id_cliente padrão do grupo JSL na plataforma LW (constante de domínio).
ID_CLIENTE_PADRAO = 167
