"""Registry de tasks do pacote `atualizacao_ativos`.

> Modo B (decisão): o fluxo são **4 tasks Ergon independentes**, ligadas por
> fases do workflow. O `auditoria_inativacoes` virou um COORDENADOR de DEBUG
> (compõe as 4 etapas localmente) — não é registrado aqui.

O `main.py` importa `TASKS` (instâncias de `ergon.task.TaskConfig`) e entrega ao
CLI (`ergon(TASKS)`).
"""

from __future__ import annotations

from atualizacao_ativos.tasks.cruzamento_ativos.config import TASK_CRUZAMENTO_ATIVOS
from atualizacao_ativos.tasks.execucao_lw.config import TASK_EXECUCAO_LW
from atualizacao_ativos.tasks.extracao_sap.config import TASK_EXTRACAO_SAP
from atualizacao_ativos.tasks.relatorio_ativos.config import TASK_RELATORIO_ATIVOS
from atualizacao_ativos.tasks.roteamento_cruzamento.config import TASK_ROTEAMENTO_CRUZAMENTO

TASKS = [
    TASK_EXTRACAO_SAP,
    TASK_CRUZAMENTO_ATIVOS,
    TASK_ROTEAMENTO_CRUZAMENTO,
    TASK_EXECUCAO_LW,
    TASK_RELATORIO_ATIVOS,
]

__all__ = [
    "TASKS",
    "TASK_EXTRACAO_SAP",
    "TASK_CRUZAMENTO_ATIVOS",
    "TASK_ROTEAMENTO_CRUZAMENTO",
    "TASK_EXECUCAO_LW",
    "TASK_RELATORIO_ATIVOS",
]
