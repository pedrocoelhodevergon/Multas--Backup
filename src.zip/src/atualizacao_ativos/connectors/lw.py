"""LwConnector — fronteira de transação do fluxo de auditoria SAP → LW.

Responsabilidade (conceito de Connector no Ergon):
  * transforma dados externos em objetos de domínio (Transaction) e vice-versa;
  * concentra TODO o I/O de arquivos (planilhas SAP de entrada, relatório xlsx de saída);
  * embrulha o acesso à LW V2 (via `LwApiService`) em operações pontuais.

A Task NÃO deve importar openpyxl nem tocar em disco. Ela só conversa com
este conector, que entrega/consome `RegistroSap`, `VeiculoLw` e `ResultadoAuditoria`.
"""

import glob
import logging
import os
from datetime import datetime
from typing import List, Optional

import openpyxl
from openpyxl.utils import get_column_letter

from atualizacao_ativos.services.lw_api.service import LwApiService
from atualizacao_ativos.services.lw_api.schema import LwApiConfig
from atualizacao_ativos.tasks.auditoria_inativacoes.constants import (
    CABECALHOS_OCULTOS,
    ELIMINAR_PLACA,
    MAPA_EMPRESAS,
    SEM_CC_NO_SAP,
)
from atualizacao_ativos.tasks.auditoria_inativacoes.rules import (
    gerar_variacao_mercosul_antiga,
    normalizar_placa,
)
from atualizacao_ativos.tasks.auditoria_inativacoes.schemas import (
    RegistroSap,
    ResultadoAuditoria,
    VeiculoLw,
)

logger = logging.getLogger(__name__)


class LwConnector:
    """Fronteira de transação: SAP (arquivos) <-> domínio <-> LW V2 (rede)."""

    def __init__(self, config: LwApiConfig, working_dir: Optional[str] = None):
        self.service = LwApiService(config)
        # Diretório padrão: /tmp se existir, senão ../downloads relativo ao pacote.
        self.working_dir = (
            working_dir
            or (
                "/tmp"
                if os.path.exists("/tmp")
                else os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "downloads"))
            )
        )
        os.makedirs(self.working_dir, exist_ok=True)

    # ------------------------------------------------------------------
    # ENTRADA: planilhas SAP → RegistroSap[]
    # ------------------------------------------------------------------

    def ler_planilhas_sap(self, sap_base_dir: str) -> dict[str, RegistroSap]:
        """Varre a pasta, consolida as planilhas SAP e devolve o mega-dicionário
        de placas únicas (com deduplicação pela variação Mercosul antiga).
        """
        sap_records: dict[str, RegistroSap] = {}
        arquivos_lidos = 0

        if not os.path.exists(sap_base_dir):
            raise FileNotFoundError(f"O diretório SAP não existe: {sap_base_dir}")

        sap_files = glob.glob(os.path.join(sap_base_dir, "*.xlsx")) + glob.glob(
            os.path.join(sap_base_dir, "*.xls")
        )
        if not sap_files:
            logger.error(f"Nenhuma planilha encontrada em '{sap_base_dir}'.")
            return sap_records

        for path in sap_files:
            logger.info(f"[ETAPA 1] Lendo planilha SAP: {os.path.basename(path)}...")
            try:
                wb = openpyxl.load_workbook(path, data_only=True)
                sheet = wb.active
            except Exception as e:  # noqa: BLE001
                logger.warning(f"Erro ao ler {os.path.basename(path)}: {e}")
                continue

            headers_sap, min_row = self._localizar_cabecalho(sheet)
            if not headers_sap:
                wb.close()
                continue

            idx = {
                "placa": next((i for i, h in enumerate(headers_sap) if "PLACA" in h), -1),
                "status": next((i for i, h in enumerate(headers_sap) if "DESMOBILIZA" in h or "STATUS" in h), -1),
                "cc": next((i for i, h in enumerate(headers_sap) if "CENTRO DE CUSTO" in h or "CC" in h), -1),
                "empresa": next((i for i, h in enumerate(headers_sap) if "EMPRESA" in h), -1),
                "cnpj": next((i for i, h in enumerate(headers_sap) if "CNPJ" in h), -1),
                "renavam": next((i for i, h in enumerate(headers_sap) if "RENAVAM" in h), -1),
                "chassi": next((i for i, h in enumerate(headers_sap) if "CHASSI" in h), -1),
            }

            for row in sheet.iter_rows(min_row=min_row, values_only=True):
                reg = self._linha_para_registro(row, idx)
                if reg is None:
                    continue
                placa_alt = gerar_variacao_mercosul_antiga(reg.placa)
                self._merge_no_dicionario(sap_records, reg, placa_alt)

            wb.close()
            arquivos_lidos += 1

        if arquivos_lidos == 0:
            logger.error("Nenhuma base SAP válida foi processada.")
            return {}

        logger.info(f"✅ Mega Dicionário SAP montado com {len(sap_records)} placas ÚNICAS.")
        return sap_records

    # ------------------------------------------------------------------
    # SAÍDA: ResultadoAuditoria[] → relatório xlsx
    # ------------------------------------------------------------------

    def salvar_relatorio(
        self, resultados: List[ResultadoAuditoria]
    ) -> Optional[str]:
        """Grava o relatório xlsx no working_dir e devolve o caminho."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        arquivo_final = os.path.join(
            self.working_dir, f"BASE_INATIVACOES_LW_{timestamp}.xlsx"
        )

        wb_out = openpyxl.Workbook()
        ws_out = wb_out.active

        if resultados:
            cabecalhos = [
                k for k in resultados[0].model_dump().keys()
                if k not in {c.lower() for c in CABECALHOS_OCULTOS}
            ]
            ws_out.append(cabecalhos)
            for r in resultados:
                dados = r.model_dump()
                ws_out.append([dados.get(c, "") for c in cabecalhos])
        else:
            ws_out.append(["NENHUMA AÇÃO NECESSÁRIA. A BASE ESTÁ LIMPA."])

        wb_out.save(arquivo_final)
        logger.info(f"📁 Relatório consolidado salvo em: {arquivo_final}")
        return arquivo_final

    # ------------------------------------------------------------------
    # LW V2 (delega ao Service, mas embrulhado como operação da fronteira)
    # ------------------------------------------------------------------

    def listar_veiculos_ativos(self) -> dict[str, VeiculoLw]:
        veiculos = self.service.listar_todos_ativos()
        registros: dict[str, VeiculoLw] = {}
        for v in veiculos:
            pl = normalizar_placa(v.get("placa", ""))
            if pl:
                registros[pl] = VeiculoLw(
                    id=v.get("id"),
                    placa=pl,
                    status_frota=str(v.get("statusFrota", "")),
                    id_grupo=v.get("idGrupo"),
                    grupos=v.get("grupos") or [],
                    historicos=v.get("historicos") or [],
                )
        return registros

    def carregar_dicionario_grupos(self) -> dict[str, int]:
        """De-Para: Centro de Custo / nome do grupo → id do grupo na LW."""
        mapa: dict[str, int] = {}
        for g in self.service.listar_grupos():
            id_grupo = g.get("id")
            cc = str(g.get("centroCusto", "")).strip()
            nome = str(g.get("nomeGrupo", "")).strip()
            if cc and cc not in ["-", "0"]:
                mapa[cc] = id_grupo
            if nome:
                mapa[nome] = id_grupo
        return mapa

    def consultar_veiculo_por_placa(self, placa: str) -> Optional[VeiculoLw]:
        v = self.service.consultar_veiculo_unico_v2(placa)
        if not v:
            return None
        return VeiculoLw(
            id=v.get("id"),
            placa=normalizar_placa(placa),
            status_frota=str(v.get("statusFrota", "")),
            id_grupo=v.get("idGrupo"),
            grupos=v.get("grupos") or [],
            historicos=v.get("historicos") or [],
        )

    # --- Operações de escrita direta na LW V2 -----------------------------

    def inativar(self, id_veiculo: int) -> tuple[bool, str]:
        return self.service.inativar_veiculos_v2([id_veiculo])

    def ativar(self, id_veiculo: int) -> tuple[bool, str]:
        return self.service.ativar_veiculos_v2([id_veiculo])

    def criar_centro_custo(self, *, centro_custo: str, cnpj: str, nome_empresa: str) -> tuple[bool, int | None, str]:
        """Cria o grupo do CC, sem duplicar, e devolve seu ID LW."""
        cc = str(centro_custo or "").strip()
        cnpj_digits = "".join(ch for ch in str(cnpj or "") if ch.isdigit())
        if not cc or cc in {SEM_CC_NO_SAP, "NÃO INFORMADO", "NÃO CADASTRADO"}:
            return False, None, "Centro de custo ausente no SAP; criação bloqueada."
        if not cnpj_digits:
            return False, None, "CNPJ ausente no SAP; criação do centro de custo bloqueada."

        existentes = self.service.listar_grupos()
        for grupo in existentes:
            if str(grupo.get("centroCusto", "")).strip() == cc:
                return True, grupo.get("id"), "Centro de custo já existente na LW."

        base = str(nome_empresa or "").strip() or "EMPRESA"
        if base.upper().startswith("EMPRESA ") and base.split()[-1].isdigit():
            base = "EMPRESA"
        nome = f"{base} - {cnpj_digits}"
        nomes_existentes = {str(g.get("nomeGrupo", "")).strip().upper() for g in existentes}
        if nome.upper() in nomes_existentes:
            for sufixo in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
                candidato = f"{nome} {sufixo}"
                if candidato.upper() not in nomes_existentes:
                    nome = candidato
                    break

        email = os.getenv("LW_GRUPO_EMAIL", "")
        payload = {
            "centroCusto": cc,
            "nomeGrupo": nome,
            "cnpj": cnpj_digits,
            "telefone": os.getenv("LW_GRUPO_TELEFONE", ""),
            "email": email,
            "emailCopia": os.getenv("LW_GRUPO_EMAIL_COPIA", email),
        }
        try:
            resposta = self.service.cadastrar_grupo_centro_custo(payload)
            return True, resposta.get("id"), f"Centro de custo criado: {nome}"
        except Exception as exc:  # noqa: BLE001
            logger.exception("Falha ao criar centro de custo %s na LW.", cc)
            return False, None, f"Falha ao criar centro de custo na LW: {exc}"

    def mobilizar_centro_custo(self, id_veiculo: int, id_grupo: int) -> tuple[bool, str]:
        return self.service.mobilizar_veiculo_grupo(
            id_veiculo=id_veiculo,
            id_grupo=id_grupo,
            id_grupo_historico=0,
        )

    # ------------------------------------------------------------------
    # Internos (parse das planilhas)
    # ------------------------------------------------------------------

    @staticmethod
    def _localizar_cabecalho(sheet) -> tuple[list, int]:
        """Detecta a linha do cabeçalho (contém 'PLACA') e devolve (headers, min_row)."""
        for i in range(1, 6):
            row_vals = [
                str(cell.value).strip().upper() if cell.value else ""
                for cell in sheet[i]
            ]
            if any("PLACA" in h for h in row_vals):
                return row_vals, i + 1
        return [], 1

    @staticmethod
    def _linha_para_registro(row, idx: dict) -> Optional[RegistroSap]:
        if not row or idx["placa"] >= len(row) or row[idx["placa"]] is None:
            return None

        placa_sap = normalizar_placa(str(row[idx["placa"]]))
        if not placa_sap:
            return None

        def _val(pos: int, default: str = "") -> str:
            if 0 <= pos < len(row) and row[pos] is not None:
                return str(row[pos]).strip()
            return default

        status_raw = _val(idx["status"], "EM OPERAÇÃO").upper()
        is_sap_active = (
            ("OPERAÇÃO" in status_raw)
            or ("ATIVO" in status_raw)
            or ("OPR" in status_raw)
            or ("DESMOBILIZA" not in status_raw)
        )
        cc_sap = _val(idx["cc"], SEM_CC_NO_SAP)
        cnpj_sap = "".join(c for c in _val(idx["cnpj"]) if c.isdigit())
        renavam_sap = _val(idx["renavam"])
        chassi_sap = _val(idx["chassi"])

        codigo_empresa = _val(idx["empresa"], "1000")
        if codigo_empresa.isdigit():
            codigo_empresa = str(int(codigo_empresa))
        nome_empresa = MAPA_EMPRESAS.get(codigo_empresa, f"EMPRESA {codigo_empresa}")

        return RegistroSap(
            placa=placa_sap,
            is_active=is_sap_active,
            status_bruto=status_raw,
            cc=cc_sap,
            codigo_empresa=codigo_empresa,
            empresa=nome_empresa,
            renavam=renavam_sap,
            cnpj=cnpj_sap,

            chassi=chassi_sap,
        )

    @staticmethod
    def _merge_no_dicionario(
        sap_records: dict, reg: RegistroSap, placa_alt: Optional[str]
    ) -> None:
        """Dedup por placa (e variação Mercosul), priorizando o registro ativo."""
        chave_existente = None
        if reg.placa in sap_records:
            chave_existente = reg.placa
        elif placa_alt and placa_alt in sap_records:
            chave_existente = placa_alt

        if chave_existente:
            if not sap_records[chave_existente].is_active and reg.is_active:
                sap_records[chave_existente] = reg
        else:
            sap_records[reg.placa] = reg
