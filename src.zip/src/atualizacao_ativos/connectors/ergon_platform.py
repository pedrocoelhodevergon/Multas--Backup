"""ErgonPlatformConnector — fronteira de transação entre a auditoria e o Ergon.

Responsabilidade (conceito de Connector no template):
  * transforma um resultado da auditoria (domínio) em `CreateItemInput` / `Transaction`;
  * decide o roteamento de fases (Cruzamento / Validação Humana / Concluído / Erros);
  * despacha as transações para a plataforma via o conector Ergon de baixo nível.

A Task (regra de negócio) NÃO conhece `CreateItemInput` nem `Transaction` — só
este conector. O runner local (`tasks/run.py`) orquestra e delega a formatação
e o despacho para cá.

> Nota: o `backend` é o conector Ergon de baixo nível (o que hoje é devolvido por
> `build_ativos_connector()`). Ele expõe `dispatch_transactions(list[Transaction])`.
"""

from __future__ import annotations

import logging
import random
import time
import uuid
from typing import Any, List, Optional

import os
import uuid as _uuid

from ergon.connector import ConnectorConfig
from ergon.connector.connector import Connector
from ergon.connector.transaction import Transaction
from ergon.connector.ergon_platform import (
    CreateItemInput,
    ErgonPlatformClient,
    ErgonPlatformConnector as BuiltInErgonPlatformConnector,
    ErgonPlatformProducerConfig,
)

from atualizacao_ativos.tasks.auditoria_inativacoes.workflow import build_workflow_config

logger = logging.getLogger(__name__)


def _build_backend(raw_connector) -> Any:
    """Instancia o conector Ergon de baixo nível a partir do `ConnectorConfig`.

    O `settings.platform_producer_connector(...)` devolve um `ConnectorConfig`
    do template. O modo de instanciar varia conforme a versão; tentamos os
    padrões mais comuns e, se nenhum bater, criamos direto a partir de
    `connector(**kwargs)`.
    """
    # ConnectorConfig costuma expor um builder.
    for metodo in ("build", "create", "to_connector", "instantiate"):
        fn = getattr(raw_connector, metodo, None)
        if callable(fn):
            try:
                return fn()
            except Exception as exc:  # noqa: BLE001
                logger.warning("Falha ao instanciar via %s(): %s", metodo, exc)

    connector_cls = getattr(raw_connector, "connector", None)
    kwargs = getattr(raw_connector, "kwargs", None) or {}
    if connector_cls is not None:
        return connector_cls(**kwargs)

    raise TypeError(
        f"Impossível construir o backend Ergon a partir de {type(raw_connector).__name__!r}."
    )


def build_ativos_connector():
    """Constrói e devolve o conector Ergon de baixo nível (backend).

    ⚠️ Este builder retorna o BACKEND (conector Ergon do framework), NÃO o
    wrapper `ErgonPlatformConnector` deste módulo. Quem precisa do wrapper é o
    runner, que o envolve uma única vez:

        ErgonPlatformConnector(build_ativos_connector(), workflow_config=...)

    NÃO envolva aqui dentro — isso causaria wrapper-dentro-de-wrapper e o
    `despachar` receberia um wrapper (sem `dispatch_transactions`).
    """
    import atualizacao_ativos.tasks.settings as settings

    wf = build_workflow_config()
    raw_connector = settings.platform_producer_connector(wf.workflow_id, wf.fase_cruzamento)
    backend = _build_backend(raw_connector)
    logger.info("Backend Ergon instanciado: %s", type(backend).__name__)
    return backend

# Ações que o robô executa automaticamente na LW.
_ACOES_AUTOMATICAS = {"INATIVAÇÃO", "REATIVAR", "ALTERAÇÃO DE CENTRO DE CUSTO"}


def _to_dict(item) -> dict:
    """Normaliza um item para dict com chaves em MAIÚSCULAS.

    O conector e a task de escrita esperam chaves UPPER (ex.: PLACA_REGISTRADA_LW,
    ACAO_REQUERIDA, ID_VEICULO_LW), mas o `ResultadoAuditoria` (Pydantic)
    serializa em lowercase/snake_case (ex.: placa_registrada_lw, acao_requerida).
    Aqui uniformizamos para UPPER para que `formatar_card`, `_field_values` e
    `ExecucaoLwTask.executar()` leiam os campos corretamente.
    """
    if isinstance(item, dict):
        # já tratado; garante UPPER apenas se as chaves estiverem snake_case
        if any(not isinstance(k, str) or not k.isupper() for k in item):
            return {str(k).upper(): v for k, v in item.items()}
        return item
    if hasattr(item, "model_dump"):
        dumped = item.model_dump()
        return {str(k).upper(): v for k, v in dumped.items()}
    return {str(k).upper(): v for k, v in dict(item).items()}


def mapear_acao_select(acao_raw: str) -> str:
    """Normaliza a ACAO_REQUERIDA para o rótulo usado nos cards do Ergon."""
    acao_upper = str(acao_raw or "").upper()
    if "INATIVA" in acao_upper:
        return "INATIVAÇÃO"
    if "INCOMPLETO" in acao_upper or "DADOS" in acao_upper:
        return "DADOS INCOMPLETOS"
    if "CADASTRAR" in acao_upper or "CADASTRO" in acao_upper:
        return "CADASTRAR"
    if "REATIVAR" in acao_upper:
        return "REATIVAR"
    if "EMPRESA" in acao_upper or "CNPJ" in acao_upper:
        return "ALTERAÇÃO DE EMPRESA/CNPJ"
    return "ALTERAÇÃO DE CENTRO DE CUSTO"


def selecionar_amostra_diversificada(resultados: list, limite: int) -> list:
    """Pega 1 de cada tipo de ação + completa aleatoriamente até o limite."""
    grupos: dict[str, list] = {}
    for item in resultados:
        acao = _to_dict(item).get("ACAO_REQUERIDA", "OUTROS")
        grupos.setdefault(acao, []).append(item)

    amostra = []
    for itens in grupos.values():
        if len(amostra) < limite and itens:
            amostra.append(itens.pop(0))

    itens_restantes = [item for sublist in grupos.values() for item in sublist]
    random.shuffle(itens_restantes)
    sobram = limite - len(amostra)
    if sobram > 0:
        amostra.extend(itens_restantes[:sobram])
    return amostra


def selecionar_um_de_cada_cenario(resultados: list) -> list:
    """Pega um card representativo de cada tipo de divergência."""
    cenarios: dict[str, dict] = {}
    for item in resultados:
        acao = mapear_acao_select(_to_dict(item).get("ACAO_REQUERIDA"))
        cenarios.setdefault(acao, item)
    amostra = list(cenarios.values())
    logger.info(f"🎯 [CENÁRIOS] {len(amostra)} cards representativos selecionados (1 de cada tipo).")
    return amostra


class ErgonPlatformConnector:
    """Encapsula a formatação e o despacho de cards para o workflow do Ergon."""

    def __init__(self, backend, workflow_config=None):
        """`backend`: conector Ergon de baixo nível com `dispatch_transactions`.

        `workflow_config`: `WorkflowAtivosConfig` (IDs de workflow/fase). Se
        omitido, é montado do ambiente via `build_workflow_config()`.
        """
        self.backend = backend
        self.workflow_config = workflow_config or build_workflow_config()

    # ------------------------------------------------------------------
    # Formatação de um card (e do card de histórico, se houver)
    # ------------------------------------------------------------------

    def formatar_card(
        self,
        linha_dados: dict,
        task_auditoria: Any,
        modo_automatico: bool,
    ) -> List[CreateItemInput]:
        """Constrói o(s) `CreateItemInput` de um registro da auditoria.

        Em modo automático, executa a ação na LW via `task_auditoria` e roteia o
        card para Concluído / Validação Humana / Erros conforme o resultado.
        Em modo passo-a-passo, insere na Fase Inicial (Cruzamento).
        """
        # Aceita `ResultadoAuditoria` (Pydantic) ou dict — normaliza aqui.
        linha_dados = _to_dict(linha_dados)

        placa_lw = str(linha_dados.get("PLACA_REGISTRADA_LW", "")).strip()
        placa_sap = str(linha_dados.get("PLACA_CRUZADA_SAP", "")).strip()
        placa_principal = placa_lw if placa_lw and placa_lw != "NÃO LOCALIZADA" else placa_sap

        renavam = str(linha_dados.get("RENAVAM_SAP", "")).strip()
        chassi = str(linha_dados.get("CHASSI_SAP", "")).strip()
        acao_texto = mapear_acao_select(linha_dados.get("ACAO_REQUERIDA"))

        w = self.workflow_config
        phase_cruzamento_id = w.fase_cruzamento
        phase_validacao_id = w.fase_validacao_humana
        phase_concluido_id = w.fase_finalizado
        phase_erros_id = w.fase_erros

        timestamp_atual = time.strftime("%Y-%m-%d %H:%M:%S")
        titulo_customizado = None
        payload_historico = None

        if not modo_automatico:
            fase_destino_id = phase_cruzamento_id
            status_execucao = "AGUARDANDO_ROTEAMENTO"
            msg_retorno = "Card inserido na Fase Inicial para demonstração."
            log_detalhado = f"[{timestamp_atual}] Card na Fase Inicial (Cruzamento)."
        else:
            (
                fase_destino_id,
                status_execucao,
                log_detalhado,
                msg_retorno,
                titulo_customizado,
                payload_historico,
            ) = self._aplicar_acoes_automaticas(
                linha_dados,
                task_auditoria,
                placa_principal,
                placa_lw,
                placa_sap,
                acao_texto,
                timestamp_atual,
                phase_cruzamento_id,
                phase_validacao_id,
                phase_concluido_id,
                phase_erros_id,
            )

            if status_execucao == "SUCESSO":
                field_values = self._field_values(
                    linha_dados,
                    placa_principal,
                    placa_lw,
                    placa_sap,
                    renavam,
                    chassi,
                    acao_texto,
                    status_execucao,
                    msg_retorno,
                    timestamp_atual,
                    log_detalhado,
                )
                # O sucesso não traz título customizado; usa um padrão para o card.
                titulo_sucesso = titulo_customizado or f"{acao_texto} - {placa_principal}"
                return [self._build_card(titulo_sucesso, placa_principal, field_values, fase_destino_id)]

        field_values = self._field_values(
            linha_dados,
            placa_principal,
            placa_lw,
            placa_sap,
            renavam,
            chassi,
            acao_texto,
            status_execucao,
            msg_retorno,
            timestamp_atual,
            log_detalhado,
        )

        if modo_automatico and acao_texto not in _ACOES_AUTOMATICAS:
            field_values["DECISAO_DO_OPERADOR"] = ["Ignorar Divergência"]

        titulo_card = titulo_customizado or f"{acao_texto.title()} - {field_values['PLACA']}"
        payload_principal = self._build_card(titulo_card, placa_principal, field_values, fase_destino_id)

        payloads_gerados = [payload_principal]
        if payload_historico:
            payloads_gerados.append(payload_historico)
        return payloads_gerados

    # ------------------------------------------------------------------
    # Despacho
    # ------------------------------------------------------------------

    def despachar(self, payloads: List[CreateItemInput] | List[List[CreateItemInput]]) -> List[str]:
        """Envolve os payloads em `Transaction`s e despacha para o Ergon.

        Aceita uma lista achatada de payloads, ou uma lista de listas
        (ex.: [principal, histórico] por registro). O retorno são os IDs.
        """
        achatados = []
        for p in payloads:
            if isinstance(p, list):
                achatados.extend(p)
            else:
                achatados.append(p)
        transacoes = [Transaction(id=str(uuid.uuid4()), payload=p) for p in achatados]
        return self._dispatch_backend(transacoes)

    def _dispatch_backend(self, transacoes) -> List[str]:
        """Chama o método de despacho do backend Ergon, detectando o nome real.

        O método de produção varia conforme a versão do framework. Tentamos os
        mais comuns e, se nenhum existir, listamos os métodos disponíveis.
        """
        logger.info(
            "[DEBUG-DESPACHO] backend=%s | métodos públicos=%s",
            type(self.backend).__name__,
            [m for m in dir(self.backend) if not m.startswith("_")],
        )
        for nome in ("dispatch_transactions", "dispatch", "produce", "send", "create_items"):
            fn = getattr(self.backend, nome, None)
            if not callable(fn):
                continue
            logger.info("[DEBUG-DESPACHO] Despachando via backend.%s(...)", nome)
            return fn(transacoes)

        metodos = [m for m in dir(self.backend) if not m.startswith("_")]
        raise AttributeError(
            "O backend Ergon não expõe nenhum método de despacho reconhecido "
            "(dispatch_transactions/dispatch/produce/send/create_items). "
            f"Métodos disponíveis: {metodos}"
        )

    # ------------------------------------------------------------------
    # Internos
    # ------------------------------------------------------------------

    def _aplicar_acoes_automaticas(
        self,
        linha_dados: dict,
        task: Any,
        placa_principal: str,
        placa_lw: str,
        placa_sap: str,
        acao_texto: str,
        timestamp_atual: str,
        phase_cruzamento_id: str,
        phase_validacao_id: str,
        phase_concluido_id: str,
        phase_erros_id: str,
    ) -> tuple[str, str, str, str, Optional[str], Optional[CreateItemInput]]:
        """Executa a ação na LW e retorna (fase, status, log, msg, título, histórico)."""
        logger.info(
            "[DEBUG-ERGON] roteando %s | acao=%r | automatica=%s",
            placa_principal,
            acao_texto,
            acao_texto in _ACOES_AUTOMATICAS,
        )
        if acao_texto in _ACOES_AUTOMATICAS:
            logger.info(
                "[DEBUG-ERGON] ⚙️ Executando atualização direta na LW para %s | Ação: %s",
                placa_principal,
                acao_texto,
            )
            sucesso, msg_retorno = task.executar_atualizacao_direta_lw(linha_dados)
            logger.info(
                "[DEBUG-ERGON] resultado da LW: sucesso=%s | msg=%r",
                sucesso,
                msg_retorno,
            )

            if sucesso:
                payload_historico = self._build_historico(
                    placa_principal, acao_texto, linha_dados, timestamp_atual
                )
                log_detalhado = (
                    f"[{timestamp_atual}] SUCESSO - API LW ATUALIZADA\n"
                    f"Placa: {placa_principal}\nRetorno API: {msg_retorno}"
                )
                return phase_concluido_id, "SUCESSO", log_detalhado, msg_retorno, None, payload_historico

            if str(msg_retorno).startswith("VALIDACAO_HUMANA:"):
                titulo = f"Centro de Custo não cadastrado na LW - {placa_principal}"
                log_detalhado = (
                    f"[{timestamp_atual}] PENDENTE DE VALIDAÇÃO HUMANA\n"
                    f"Placa: {placa_principal}\n"
                    f"Motivo: O Centro de Custo do SAP '{linha_dados.get('CENTRO_CUSTO_SAP')}' "
                    "não existe no cadastro da LW. É necessário criá-lo manualmente no portal."
                )
                return phase_validacao_id, "AGUARDANDO_VALIDACAO_HUMANA", log_detalhado, "Centro de Custo Ausente na LW (Criar no Portal)", titulo, None

            log_detalhado = (
                f"[{timestamp_atual}] ERRO NA ATUALIZAÇÃO LW\n"
                f"Placa: {placa_principal}\nAção: {acao_texto}\nDetalhe: {msg_retorno}"
            )
            return phase_erros_id, "ERRO DE API", log_detalhado, msg_retorno, None, None

        # Outros casos → Validação Humana com motivo de divergência.
        motivo_div = str(linha_dados.get("MOTIVO_DIVERGENCIA", "Análise de Operador Requerida"))
        titulo = f"{acao_texto.title()} ({motivo_div}) - {placa_principal}"
        log_detalhado = (
            f"[{timestamp_atual}] PENDENTE DE VALIDAÇÃO HUMANA\n"
            f"Placa: {placa_principal}\nMotivo: {motivo_div}"
        )
        return phase_validacao_id, "AGUARDANDO_VALIDACAO_HUMANA", log_detalhado, motivo_div, titulo, None

    @staticmethod
    def _normalizar_obrigatorio(valor, padrao: str = "NÃO INFORMADO") -> str:
        if valor is None:
            return padrao
        s = str(valor).strip()
        if not s or s.lower() == "nan":
            return padrao
        return s

    def _field_values(
        self,
        linha_dados: dict,
        placa_principal: str,
        placa_lw: str,
        placa_sap: str,
        renavam: str,
        chassi: str,
        acao_texto: str,
        status_execucao: str,
        msg_retorno: str,
        timestamp_atual: str,
        log_detalhado: str,
    ) -> dict:
        n = self._normalizar_obrigatorio
        return {
            "PLACA": n(placa_principal),
            "PLACA_LW": n(placa_lw),
            "PLACA_CRUZADA_SAP": n(placa_sap),
            "RENAVAM": renavam,
            "CHASSI": chassi,
            "EMPRESA": n(linha_dados.get("EMPRESA_NO_SAP"), padrao="JSL"),
            "CNPJ_SAP": n(linha_dados.get("CNPJ_SAP")),
            "CENTRO_DE_CUSTO": n(linha_dados.get("CENTRO_CUSTO_SAP")),

            "CENTRO_CUSTO_LW": n(linha_dados.get("CENTRO_CUSTO_ATUAL_LW")),
            "STATUS": n(linha_dados.get("STATUS_NO_SAP"), padrao="EM OPERAÇÃO"),
            "STATUS_NA_LW": n(linha_dados.get("STATUS_NA_LW"), padrao="ATIVO"),
            "ACAO_REQUERIDA": acao_texto,
            "MOTIVO_DIVERGENCIA": n(linha_dados.get("MOTIVO_DIVERGENCIA"), padrao="AUDITORIA_SISTEMA"),
            "STATUS_EXECUCAO": status_execucao,
            "STATUS_PROCESSAMENTO": status_execucao,
            "MENSAGEM_RETORNO_LW": str(msg_retorno),
            # Campos de auditoria exibidos também na fase Finalizado. Mantemos
            # os nomes históricos para compatibilidade com o Workflow legado.
            "VALOR_ANTERIOR": self._valor_anterior(linha_dados, acao_texto),
            "VALOR_NOVO": self._valor_novo(linha_dados, acao_texto),
            "LOG_EXECUCAO_LW": str(log_detalhado),
            "LOG_EXECUCAO": str(log_detalhado),
            "DATA_PROCESSAMENTO": timestamp_atual,
            "TRACEBACK_LOG / LOG_EXECUCAO": str(log_detalhado),
            "TIPO_DE_EXCECAO": n(linha_dados.get("MOTIVO_DIVERGENCIA")),
            "TIPO_EXCECAO": n(linha_dados.get("MOTIVO_DIVERGENCIA")),
            "RENAVAM_COMPLEMENTAR": renavam,
            "CHASSI_COMPLEMENTAR": chassi,
        }

    @staticmethod
    def _valor_anterior(linha_dados: dict, acao_texto: str) -> str:
        """Valor existente na LW antes da operação automática."""
        if "CENTRO DE CUSTO" in acao_texto:
            return ErgonPlatformConnector._normalizar_obrigatorio(
                linha_dados.get("CENTRO_CUSTO_ATUAL_LW")
            )
        if "REATIVAR" in acao_texto or "INATIVA" in acao_texto:
            return ErgonPlatformConnector._normalizar_obrigatorio(
                linha_dados.get("STATUS_NA_LW"), padrao="NÃO INFORMADO"
            )
        return ErgonPlatformConnector._normalizar_obrigatorio(
            linha_dados.get("VALOR_ANTERIOR")
        )

    @staticmethod
    def _valor_novo(linha_dados: dict, acao_texto: str) -> str:
        """Valor esperado na LW depois da operação automática."""
        if "CENTRO DE CUSTO" in acao_texto:
            return ErgonPlatformConnector._normalizar_obrigatorio(
                linha_dados.get("CENTRO_CUSTO_SAP")
            )
        if "REATIVAR" in acao_texto:
            return "ATIVO"
        if "INATIVA" in acao_texto:
            return "INATIVO"
        return ErgonPlatformConnector._normalizar_obrigatorio(
            linha_dados.get("VALOR_NOVO")
        )

    def _build_card(self, titulo: str, placa_principal: str, field_values: dict, fase_destino_id: str) -> CreateItemInput:
        # `CreateItemInput.title` é str obrigatória; garante que nunca é None.
        titulo_valido = str(titulo).strip() or f"{field_values.get('ACAO_REQUERIDA', 'CARD')} - {placa_principal}"
        return CreateItemInput(
            title=titulo_valido,
            workflow_id=self.workflow_config.workflow_id or None,
            phase_id=fase_destino_id,
            field_values=field_values,
        )

    def _build_historico(
        self, placa_principal: str, acao_texto: str, linha_dados: dict, timestamp_atual: str
    ) -> CreateItemInput:
        return CreateItemInput(
            title=f"Histórico {placa_principal} - {acao_texto}",
            workflow_id=self.workflow_config.workflow_id or None,
            phase_id=self.workflow_config.fase_historico,
            field_values={
                "PLACA": placa_principal,
                "TIPO_ALTERACAO": acao_texto,
                "VALOR_ANTERIOR": linha_dados.get("CENTRO_CUSTO_ATUAL_LW", "N/A"),
                "VALOR_NOVO": linha_dados.get("CENTRO_CUSTO_SAP", "N/A"),
                "DATA_HORA": timestamp_atual,
                "ORIGEM": "Robô Sincronização SAP x LW",
            },
        )


# ----------------------------------------------------------------------
# Dry-run (offline) — item 10: usar o built-in; dry-run só para debug.
# ----------------------------------------------------------------------


class DryRunAtivosConnector(Connector):
    """Offline stand-in que loga o card que seria criado na plataforma."""

    def __init__(self, producer_config: ErgonPlatformProducerConfig | None = None) -> None:
        self._producer_config = producer_config or ErgonPlatformProducerConfig()
        self.created_cards: list[dict] = []

    def fetch_transactions(self, *args, **kwargs):
        raise NotImplementedError("DryRunAtivosConnector é somente para saída.")

    def dispatch_transactions(self, transaction, *args, **kwargs):
        from ergon.connector.ergon_platform.utils import normalize_create_payload

        ids = []
        for tr in transaction or []:
            card = normalize_create_payload(tr.payload)
            card.setdefault("workflow_id", self._producer_config.workflow_id)
            card.setdefault("phase_id", self._producer_config.phase_id)
            self.created_cards.append(card)
            ids.append(f"dry-run-{_uuid.uuid4()}")
        return ids

    def close(self):
        return


def _has_platform_credentials(workflow_id, phase_id):
    return bool(
        os.getenv("ERGON_CLIENT_ID")
        and os.getenv("ERGON_CLIENT_SECRET")
        and workflow_id
        and phase_id
    )


def build_ativos_connector_config(workflow_id: str | None, phase_id: str | None) -> ConnectorConfig:
    """`ConnectorConfig` de saída: live (built-in) ou dry-run sem credenciais."""
    producer_config = ErgonPlatformProducerConfig(workflow_id=workflow_id, phase_id=phase_id)
    if not _has_platform_credentials(workflow_id, phase_id):
        return ConnectorConfig(connector=DryRunAtivosConnector, kwargs={"producer_config": producer_config})
    client = ErgonPlatformClient(
        client_id=os.environ["ERGON_CLIENT_ID"],
        client_secret=os.environ["ERGON_CLIENT_SECRET"],
        base_url=os.getenv("ERGON_BASE_URL", "https://platform.ergondata.ai"),
    )
    return ConnectorConfig(
        connector=BuiltInErgonPlatformConnector,
        kwargs={"client": client, "producer_config": producer_config},
    )
